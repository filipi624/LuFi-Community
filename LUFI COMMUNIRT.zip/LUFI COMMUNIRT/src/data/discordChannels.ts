export interface DiscordChannel {
  name: string;
  category: string;
  description: string;
  valueEstimate: string;
  iconType: string;
  badge?: string;
  highlights: string[];
}

export interface DiscordCategory {
  id: string;
  title: string;
  group: 'fornecedores' | 'softwares' | 'marketing' | 'packs';
  icon: string;
  channels: DiscordChannel[];
}

export const DISCORD_INVITE_URL = 'https://discord.gg/uwWEa7DrcJ';

export const DISCORD_CATEGORIES: DiscordCategory[] = [
  {
    id: 'fornecedores-atacado',
    title: 'FORNECEDORES ATACADO',
    group: 'fornecedores',
    icon: 'Star',
    channels: [
      {
        name: 'roupas',
        category: 'FORNECEDORES ATACADO',
        iconType: 'Star',
        description: 'Fornecedores diretos das maiores fábricas de vestuário streetwear, grifes importadas e moda casual.',
        valueEstimate: 'R$ 350,00',
        highlights: ['Preço de custo de fábrica', 'Catálogos atualizados com fotos reais', 'Envio com rastreio para todo o Brasil']
      },
      {
        name: 'eletrônico',
        category: 'FORNECEDORES ATACADO',
        iconType: 'Star',
        description: 'Contatos validados de atacado de iPhones lacrados e de vitrine, Xiaomi, periféricos gamers e fones.',
        valueEstimate: 'R$ 500,00',
        highlights: ['Garantia de procedência', 'Tabelas diárias atualizadas com cotação', 'Margens de lucro de 40% a 120%']
      },
      {
        name: 'ferramentas-e-brinquedos',
        category: 'FORNECEDORES ATACADO',
        iconType: 'Star',
        description: 'Distribuidores de ferramentas industriais e elétricas, utilidades domésticas e brinquedos populares.',
        valueEstimate: 'R$ 200,00',
        highlights: ['Produtos de alto giro no Mercado Livre e Shopee', 'Lotes fechados com desconto progressivo']
      },
      {
        name: 'feminina',
        category: 'FORNECEDORES ATACADO',
        iconType: 'Star',
        description: 'Moda feminina contemporânea, vestidos de festa, conjuntos, biquínis e moda fitness com confecção premium.',
        valueEstimate: 'R$ 250,00',
        highlights: ['Peças com fotos profissionais para seu catálogo', 'Dropshipping nacional disponível']
      },
      {
        name: 'tênis',
        category: 'FORNECEDORES ATACADO',
        iconType: 'Star',
        description: 'Fornecedores de tênis premium linha importada (Nike Dunk, Jordan, Adidas Samba, Asics, Mizuno).',
        valueEstimate: 'R$ 400,00',
        highlights: ['Acabamento impecável e caixas originais', 'Preço no atacado a partir de R$ 90/par']
      },
      {
        name: 'joias-e-perfumes',
        category: 'FORNECEDORES ATACADO',
        iconType: 'Star',
        description: 'Pratas 925 legítimas, correntes e anéis banhados a ouro 18k, e perfumes importados lacrados e contratipos.',
        valueEstimate: 'R$ 380,00',
        highlights: ['Certificado de garantia de pratas', 'Perfumes com fixação de 8h a 12h']
      },
      {
        name: 'relógio',
        category: 'FORNECEDORES ATACADO',
        iconType: 'Star',
        description: 'Atacado de relógios masculinos e femininos: Casio Vintage, Invicta, Poedagar, Naviforce e smartwatches.',
        valueEstimate: 'R$ 280,00',
        highlights: ['Acompanha estojos e manuais', 'Alta saída rápida em marketplaces']
      }
    ]
  },
  {
    id: 'fornecedores-digital',
    title: 'FORNECEDORES DIGITAL',
    group: 'fornecedores',
    icon: 'Laptop',
    channels: [
      {
        name: 'marketplaces-globais',
        category: 'FORNECEDORES DIGITAL',
        iconType: 'Laptop',
        description: 'Lista secreta de marketplaces globais na Ásia e Leste Europeu para comprar contas e ativos digitais.',
        valueEstimate: 'R$ 300,00',
        highlights: ['Preços em dólar/rublo com conversão vantajosa', 'Plataformas seguras com garantia de compra']
      },
      {
        name: 'keys-premium',
        category: 'FORNECEDORES DIGITAL',
        iconType: 'Laptop',
        description: 'Chaves originais Windows 11/10 Pro, Pacote Office 365, Antivírus e softwares profissionais a centavos.',
        valueEstimate: 'R$ 290,00',
        highlights: ['Revenda fácil por 5x a 10x o valor investido', 'Ativação direta nos sites oficiais']
      },
      {
        name: 'roblox-itens',
        category: 'FORNECEDORES DIGITAL',
        iconType: 'Laptop',
        description: 'Fornecedores de Robux a preço de atacado, contas raras e itens colecionáveis para revenda rápida.',
        valueEstimate: 'R$ 220,00',
        highlights: ['Métodos seguros sem banimento', 'Comunidade gamer altamente compradora']
      },
      {
        name: 'mercado-brasileiro',
        category: 'FORNECEDORES DIGITAL',
        iconType: 'Laptop',
        description: 'Contatos e fornecedores nacionais de serviços digitais, consultorias e contas prontas.',
        valueEstimate: 'R$ 250,00',
        highlights: ['Suporte em português', 'Pagamentos simplificados via Pix']
      },
      {
        name: 'smm',
        category: 'FORNECEDORES DIGITAL',
        iconType: 'Laptop',
        description: 'Os melhores servidores de painel SMM (Social Media Marketing) com custo real de R$ 0,80 por 1.000 seguidores.',
        valueEstimate: 'R$ 350,00',
        highlights: ['Seguidores, curtidas, views e membros de Discord/Telegram', 'API pronta para integrar']
      },
      {
        name: 'ggsel-igv',
        category: 'FORNECEDORES DIGITAL',
        iconType: 'Laptop',
        description: 'Tutorial e fornecedores diretos dentro do GGsel e IGVault para comprar jogos e assinaturas baratas.',
        valueEstimate: 'R$ 200,00',
        highlights: ['Steam Games com 80% de desconto', 'Assinaturas de streaming globais']
      },
      {
        name: 'valorant',
        category: 'FORNECEDORES DIGITAL',
        iconType: 'Laptop',
        description: 'Fornecedores de Valorant Points (VP) promocionais e contas smurf ou full skins.',
        valueEstimate: 'R$ 180,00',
        highlights: ['Códigos oficiais resgatáveis na Riot', 'Margem excelente para revenda']
      },
      {
        name: 'outros-gerais',
        category: 'FORNECEDORES DIGITAL',
        iconType: 'Laptop',
        badge: 'NOVO',
        description: 'Canal atualizado toda semana com novos fornecedores de diversos segmentos digitais e físicos.',
        valueEstimate: 'Inestimável',
        highlights: ['Atualizações constantes da equipe LUFI', 'Sugestões abertas para novos pedidos da comunidade']
      }
    ]
  },
  {
    id: 'super-pack-softwares',
    title: 'SUPER PACK - SOFTWARES',
    group: 'softwares',
    icon: 'Cpu',
    channels: [
      {
        name: 'claude-code',
        category: 'SUPER PACK - SOFTWARES',
        iconType: 'Laptop',
        description: 'Acessos, prompts e scripts prontos para automação de código inteligente com Claude.',
        valueEstimate: 'R$ 397,00',
        highlights: ['Pipelines prontas para desenvolvedores e criadores', 'Documentações destrinchadas']
      },
      {
        name: 'wa-sender-vitalicio',
        category: 'SUPER PACK - SOFTWARES',
        iconType: 'Laptop',
        badge: 'POPULAR',
        description: 'Disparador de mensagens em massa no WhatsApp com versão vitalícia sem pagar mensalidade.',
        valueEstimate: 'R$ 497,00',
        highlights: ['Envio ilimitado com filtros anti-ban', 'Suporte a anexos de imagem, PDF e áudio']
      },
      {
        name: 'zap-voice-vitalicio',
        category: 'SUPER PACK - SOFTWARES',
        iconType: 'Laptop',
        badge: 'EXCLUSIVO',
        description: 'Software para enviar áudios no WhatsApp como se tivessem sido gravados na hora pelo celular.',
        valueEstimate: 'R$ 397,00',
        highlights: ['Multiplica a taxa de conversão no 1 a 1', 'Salva funis de mensagens prontas com 1 clique']
      },
      {
        name: 'prompts-proibidos',
        category: 'SUPER PACK - SOFTWARES',
        iconType: 'Laptop',
        description: 'Acervo de engenharia de prompts que quebram filtros e destravam 100% do potencial do ChatGPT e Midjourney.',
        valueEstimate: 'R$ 197,00',
        highlights: ['Prompts para copy, scripts de VSL, anúncios e criação de SaaS', 'Fórmulas testadas']
      },
      {
        name: 'saas-prontos-variados',
        category: 'SUPER PACK - SOFTWARES',
        iconType: 'Laptop',
        description: 'Sistemas SaaS prontos com código-fonte para você hospedar no seu servidor e cobrar assinaturas.',
        valueEstimate: 'R$ 1.200,00',
        highlights: ['Código limpo e documentado', 'Modelos de negócio validados']
      },
      {
        name: 'clonador-de-paginas',
        category: 'SUPER PACK - SOFTWARES',
        iconType: 'Laptop',
        description: 'Ferramenta para copiar e baixar qualquer página de vendas da internet em menos de 10 segundos.',
        valueEstimate: 'R$ 297,00',
        highlights: ['Substitui links de checkout automaticamente', 'Limpa scripts de rastreamento do concorrente']
      },
      {
        name: 'fluxos-n8n',
        category: 'SUPER PACK - SOFTWARES',
        iconType: 'Laptop',
        description: 'Automações profissionais no n8n prontas para importar: CRM, WhatsApp, Typebot, Sheets e Webhooks.',
        valueEstimate: 'R$ 597,00',
        highlights: ['JSON pronto para importar com 1 clique', 'Economize centenas de horas de programação']
      },
      {
        name: 'typer-bot',
        category: 'SUPER PACK - SOFTWARES',
        iconType: 'Laptop',
        description: 'Fluxos avançados de chatbots humanizados com visual estilo Typebot para automação de vendas.',
        valueEstimate: 'R$ 347,00',
        highlights: ['Simula digitação e pausas naturais', 'Alta taxa de retenção de leads']
      },
      {
        name: 'baixar-vsl',
        category: 'SUPER PACK - SOFTWARES',
        iconType: 'Laptop',
        description: 'Script para baixar VSLs blindadas (VTurb, Panda Vídeo, YouTube oculto, Wistia) em qualidade máxima.',
        valueEstimate: 'R$ 197,00',
        highlights: ['Baixe vídeos protegidos para modelar', 'Áudio e vídeo em alta definição']
      }
    ]
  },
  {
    id: 'super-pack-aplicativos',
    title: 'SUPER PACK - APLICATIVOS',
    group: 'softwares',
    icon: 'Smartphone',
    channels: [
      {
        name: 'iptv-vitalicio',
        category: 'SUPER PACK - APLICATIVOS',
        iconType: 'Smartphone',
        badge: 'TOP',
        description: 'Listas e aplicativos com acesso a todos os canais de TV fechada, futebol, filmes e séries.',
        valueEstimate: 'R$ 299,00',
        highlights: ['Sem faturas mensais', 'Compatível com TV Box, Smart TV, Celular e PC']
      },
      {
        name: 'extensões',
        category: 'SUPER PACK - APLICATIVOS',
        iconType: 'Smartphone',
        description: 'Pacote de extensões de navegador desbloqueadas para espionar anúncios, tráfego de sites e baixar mídias.',
        valueEstimate: 'R$ 250,00',
        highlights: ['Instalação simplificada no Chrome/Brave', 'Ferramentas pagas em versão livre']
      },
      {
        name: 'painel-seven',
        category: 'SUPER PACK - APLICATIVOS',
        iconType: 'Smartphone',
        description: 'Acesso e métodos ao famoso Painel Seven para consultas e automações.',
        valueEstimate: 'R$ 350,00',
        highlights: ['Ferramenta rápida e completa', 'Acesso direto sem burocracia']
      },
      {
        name: 'games-e-emuladores',
        category: 'SUPER PACK - APLICATIVOS',
        iconType: 'Smartphone',
        description: 'Mega pack de ROMs completas e emuladores para PC, Android e consoles portáteis.',
        valueEstimate: 'R$ 180,00',
        highlights: ['Milhares de jogos clássicos e modernos', 'Configurações prontas plug-and-play']
      },
      {
        name: 'bancos-editáveis',
        category: 'SUPER PACK - APLICATIVOS',
        iconType: 'Smartphone',
        description: 'Arquivos de design para mockups realistas de comprovantes para composições gráficas.',
        valueEstimate: 'R$ 190,00',
        highlights: ['Arquivos PSD 100% editáveis no Photoshop', 'Fontes e elementos idênticos']
      }
    ]
  },
  {
    id: 'super-pack-trafego',
    title: 'SUPER PACK - TRÁFEGO PAGO | ORGÂNICO',
    group: 'marketing',
    icon: 'TrendingUp',
    channels: [
      {
        name: 'gerador-prova-social',
        category: 'SUPER PACK - TRÁFEGO PAGO | ORGÂNICO',
        iconType: 'TrendingUp',
        description: 'Ferramenta para simular notificações de vendas em tempo real, prints de WhatsApp e depoimentos.',
        valueEstimate: 'R$ 297,00',
        highlights: ['Aumenta a conversão imediata de qualquer página', 'Totalmente customizável com seu produto']
      },
      {
        name: 'geral',
        category: 'SUPER PACK - TRÁFEGO PAGO | ORGÂNICO',
        iconType: 'TrendingUp',
        description: 'Estratégias completas de aquisição de clientes no Facebook Ads, Google Ads, TikTok Ads e orgânico.',
        valueEstimate: 'R$ 497,00',
        highlights: ['Campanhas passo a passo para iniciantes e avançados', 'Métricas de otimização de ROAS']
      },
      {
        name: 'copys-scripts',
        category: 'SUPER PACK - TRÁFEGO PAGO | ORGÂNICO',
        iconType: 'TrendingUp',
        description: 'Acervo de copys e scripts de alta conversão para VSLs, anúncios, páginas e mensagens no WhatsApp.',
        valueEstimate: 'R$ 397,00',
        highlights: ['Modelos já testados que geraram milhões', 'Gatilhos mentais e quebra de objeções']
      },
      {
        name: 'funil',
        category: 'SUPER PACK - TRÁFEGO PAGO | ORGÂNICO',
        iconType: 'TrendingUp',
        description: 'Mapeamento visual e estruturas de funis de alta conversão: Perpétuo, Tripwire, Webinar e High Ticket.',
        valueEstimate: 'R$ 350,00',
        highlights: ['Diagramas prontas para implementar', 'Instruções de automação']
      },
      {
        name: 'leads',
        category: 'SUPER PACK - TRÁFEGO PAGO | ORGÂNICO',
        iconType: 'TrendingUp',
        description: 'Técnicas de extração e captação de leads segmentados por nicho e região.',
        valueEstimate: 'R$ 297,00',
        highlights: ['Métodos orgânicos e automatizados', 'Leads qualificados para fechar vendas']
      },
      {
        name: 'aquecimento-whatsapp',
        category: 'SUPER PACK - TRÁFEGO PAGO | ORGÂNICO',
        iconType: 'TrendingUp',
        description: 'Passo a passo definitivo para aquecer chips de WhatsApp novos sem levar banimento ao disparar.',
        valueEstimate: 'R$ 247,00',
        highlights: ['Rotina de 7 a 14 dias blindada', 'Preserve seus números e suas vendas']
      },
      {
        name: 'estrategias',
        category: 'SUPER PACK - TRÁFEGO PAGO | ORGÂNICO',
        iconType: 'TrendingUp',
        description: 'Hacks de escala rápida e contingência para contas de anúncios.',
        valueEstimate: 'R$ 380,00',
        highlights: ['Como não parar de rodar anúncios se uma conta cair', 'Esteiras de contingência seguras']
      }
    ]
  },
  {
    id: 'super-pack-marketing',
    title: 'SUPER PACK - MARKETING DIGITAL',
    group: 'marketing',
    icon: 'Target',
    channels: [
      {
        name: 'paginas-de-vendas-prontas',
        category: 'SUPER PACK - MARKETING DIGITAL',
        iconType: 'Target',
        badge: 'OURO',
        description: 'Dezenas de templates de páginas de vendas prontas para Elementor, WordPress e código puro.',
        valueEstimate: 'R$ 697,00',
        highlights: ['Design moderno responsivo para mobile', 'Prontas para plugar checkout e rodar']
      },
      {
        name: 'dropshipping',
        category: 'SUPER PACK - MARKETING DIGITAL',
        iconType: 'Target',
        description: 'Mineração de produtos vencedores, fornecedores nacionais com envio em 48h e temas Shopify prontos.',
        valueEstimate: 'R$ 450,00',
        highlights: ['Temas convertidos otimizados para checkout transparente', 'Produtos com alta margem']
      },
      {
        name: 'painel-smm',
        category: 'SUPER PACK - MARKETING DIGITAL',
        iconType: 'Target',
        description: 'Treinamento completo para você criar seu próprio site de revenda de seguidores e lucrar no automático.',
        valueEstimate: 'R$ 497,00',
        highlights: ['Plataforma automatizada que aceita Pix', 'Margem de 300% a 800%']
      },
      {
        name: 'cursos',
        category: 'SUPER PACK - MARKETING DIGITAL',
        iconType: 'Target',
        description: 'Centenas de cursos completos dos maiores nomes do marketing digital, tráfego, vendas e negócios.',
        valueEstimate: 'R$ 2.500,00+',
        highlights: ['Aulas completas em vídeo e materiais de apoio', 'Do iniciante ao avançado']
      },
      {
        name: 'ebook',
        category: 'SUPER PACK - MARKETING DIGITAL',
        iconType: 'Target',
        description: 'Biblioteca gigante de e-books nos mais diversos nichos prontos para leitura ou adaptação.',
        valueEstimate: 'R$ 350,00',
        highlights: ['Nichos de saúde, finanças, relacionamentos e hobbies', 'Formato PDF e Word editável']
      },
      {
        name: 'plrs',
        category: 'SUPER PACK - MARKETING DIGITAL',
        iconType: 'Target',
        description: 'Produtos com Direitos de Revenda (PLR) em português, com páginas de vendas, criativos e VSL inclusos.',
        valueEstimate: 'R$ 890,00',
        highlights: ['Coloque seu nome e fique com 100% do lucro', 'Nenhum direito autoral a pagar']
      },
      {
        name: 'pdf',
        category: 'SUPER PACK - MARKETING DIGITAL',
        iconType: 'Target',
        description: 'Guias rápidos, resumos operacionais, matrizes de decisão e checklists para executar estratégias.',
        valueEstimate: 'R$ 150,00',
        highlights: ['Conteúdo direto ao ponto sem enrolação']
      }
    ]
  },
  {
    id: 'super-pack-nicho-hot',
    title: 'SUPER PACK - NICHO HOT & IGAMING',
    group: 'packs',
    icon: 'Flame',
    channels: [
      {
        name: 'modelos-prontas',
        category: 'SUPER PACK - NICHO HOT',
        iconType: 'Flame',
        description: 'Acervo e materiais organizados para afiliação e operação no mercado de entretenimento adulto.',
        valueEstimate: 'R$ 450,00',
        highlights: ['Mídias organizadas por pastas', 'Estratégias de funil para Telegram']
      },
      {
        name: 'trafego-pago',
        category: 'SUPER PACK - NICHO HOT',
        iconType: 'Flame',
        description: 'Como rodar tráfego para nichos sensíveis (Black/Hot) sem sofrer bloqueios no Facebook e TikTok.',
        valueEstimate: 'R$ 497,00',
        highlights: ['Cloakers, páginas ponte e contingência', 'Anúncios que passam na aprovação']
      },
      {
        name: 'audios',
        category: 'SUPER PACK - NICHO HOT',
        iconType: 'Flame',
        description: 'Bancos de áudios gravados e humanizados para criar conversas convincentes e fechar vendas no WhatsApp.',
        valueEstimate: 'R$ 290,00',
        highlights: ['Áudios categorizados por contexto e objeção', 'Aumenta a conversão imediata']
      },
      {
        name: 'ferramentas',
        category: 'SUPER PACK - NICHO HOT',
        iconType: 'Flame',
        description: 'Bots e utilitários específicos para automatizar grupos de Telegram e canais de distribuição.',
        valueEstimate: 'R$ 320,00',
        highlights: ['Postagem automática agendada', 'Gestão de assinantes']
      },
      {
        name: 'raspadinha',
        category: 'SUPER PACK - IGAMING',
        iconType: 'Flame',
        description: 'Scripts e sistemas de jogos de raspadinha online para projetos de iGaming.',
        valueEstimate: 'R$ 800,00',
        highlights: ['Código fonte pronto', 'Integração com gateway de pagamento']
      },
      {
        name: 'api',
        category: 'SUPER PACK - IGAMING',
        iconType: 'Flame',
        description: 'APIs e integrações para conexão com provedores de jogos e saldo.',
        valueEstimate: 'R$ 600,00',
        highlights: ['Documentação detalhada para desenvolvedores']
      }
    ]
  },
  {
    id: 'super-pack-metodos-videos',
    title: 'SUPER PACK - MÉTODOS & VÍDEOS VIRAIS',
    group: 'packs',
    icon: 'Video',
    channels: [
      {
        name: 'metodos-black',
        category: 'SUPER PACK - MÉTODOS',
        iconType: 'Video',
        description: 'Métodos avançados que pouquíssimas pessoas conhecem sobre monetização rápida na internet.',
        valueEstimate: 'R$ 650,00',
        highlights: ['Técnicas fora da caixa', 'Atualizados constantemente pela equipe']
      },
      {
        name: 'metodos-hacker',
        category: 'SUPER PACK - MÉTODOS',
        iconType: 'Video',
        description: 'Fundamentos de cibersegurança, pentest ético e proteção de dados contra invasões.',
        valueEstimate: 'R$ 497,00',
        highlights: ['Aprenda como se proteger de golpes e invasões', 'Ferramentas de auditoria']
      },
      {
        name: 'documentos-editáveis',
        category: 'SUPER PACK - MÉTODOS',
        iconType: 'Video',
        description: 'Modelos de documentos e certificados em PSD e AI para edição criativa.',
        valueEstimate: 'R$ 250,00',
        highlights: ['Arquivos em alta resolução', 'Fácil personalização no Photoshop']
      },
      {
        name: 'cortes-gerais',
        category: 'SUPER PACK - VÍDEOS VIRAIS',
        iconType: 'Video',
        description: 'Milhares de cortes legendados com transições dinâmicas para canais dark no TikTok e Reels.',
        valueEstimate: 'R$ 350,00',
        highlights: ['Cortes de podcasts famosos e palestras', 'Gere milhões de visualizações sem aparecer']
      },
      {
        name: 'academia',
        category: 'SUPER PACK - VÍDEOS VIRAIS',
        iconType: 'Video',
        description: 'Banco de vídeos motivacionais de treino, estética e fisiculturismo em formato vertical.',
        valueEstimate: 'R$ 200,00',
        highlights: ['Qualidade 4K para criar canais fitness virais', 'Músicas e batidas sincronizadas']
      },
      {
        name: 'dinheiro',
        category: 'SUPER PACK - VÍDEOS VIRAIS',
        iconType: 'Video',
        description: 'Cenas cinematográficas de superesportivos, jatos, mansões e lifestyle de luxo.',
        valueEstimate: 'R$ 250,00',
        highlights: ['Ideal para canais de finanças, cripto e motivação', 'Vídeos sem marca d’água']
      }
    ]
  },
  {
    id: 'super-pack-conhecimento-design',
    title: 'SUPER PACK - CONHECIMENTOS, DESIGN & VARIADOS',
    group: 'packs',
    icon: 'BookOpen',
    channels: [
      {
        name: 'modelos-de-contrato',
        category: 'SUPER PACK - CONHECIMENTOS',
        iconType: 'BookOpen',
        description: 'Contratos jurídicos blindados para prestadores de serviços, gestores de tráfego, designers e freelancers.',
        valueEstimate: 'R$ 390,00',
        highlights: ['Elaborados por advogados especialistas em digital', 'Proteja-se contra calotes de clientes']
      },
      {
        name: 'cursos',
        category: 'SUPER PACK - CONHECIMENTOS',
        iconType: 'BookOpen',
        description: 'Megapack de cursos de programação, inteligência artificial, edição de vídeo, idiomas e produtividade.',
        valueEstimate: 'R$ 1.800,00',
        highlights: ['Aulas completas e organizadas', 'Tudo sem taxas extras']
      },
      {
        name: 'livros',
        category: 'SUPER PACK - CONHECIMENTOS',
        iconType: 'BookOpen',
        description: 'Coleção com os melhores livros de negócios, finanças, persuasão, mentalidade e vendas em PDF/EPUB.',
        valueEstimate: 'R$ 450,00',
        highlights: ['Mais de 500 títulos aclamados', 'Leve sua biblioteca no celular']
      },
      {
        name: 'enem',
        category: 'SUPER PACK - CONHECIMENTOS',
        iconType: 'BookOpen',
        description: 'Apostilas completas, resumos temáticos, cronogramas de estudo e simulados para o ENEM e vestibulares.',
        valueEstimate: 'R$ 290,00',
        highlights: ['Materiais dos cursinhos mais concorridos', 'Redações nota 1000 comentadas']
      },
      {
        name: 'canva-tudo',
        category: 'SUPER PACK - DESIGN',
        iconType: 'BookOpen',
        badge: 'TOP',
        description: 'Milhares de templates editáveis no Canva para redes sociais, carrosséis, anúncios, banners e cardápios.',
        valueEstimate: 'R$ 497,00',
        highlights: ['Basta abrir no Canva gratuito e editar', 'Economize horas de trabalho de design']
      },
      {
        name: 'planilhas',
        category: 'SUPER PACK - VARIADOS',
        iconType: 'BookOpen',
        description: 'Planilhas prontas de gestão financeira pessoal e empresarial, controle de estoque, cálculo de ROI e precificação.',
        valueEstimate: 'R$ 250,00',
        highlights: ['Fórmulas automáticas e gráficos intuitivos']
      },
      {
        name: 'concursos',
        category: 'SUPER PACK - VARIADOS',
        iconType: 'BookOpen',
        description: 'Materiais para concursos públicos (Polícia Federal, INSS, Tribunais, Bancos) com editais verticalizados.',
        valueEstimate: 'R$ 490,00',
        highlights: ['Direito Constitucional, Administrativo, Português e Raciocínio Lógico']
      },
      {
        name: 'otaku',
        category: 'SUPER PACK - VARIADOS',
        iconType: 'BookOpen',
        description: 'Canais especiais com mangás completos, wallpapers 4K e acervos para fãs da cultura japonesa.',
        valueEstimate: 'R$ 120,00',
        highlights: ['Traduções de alta qualidade', 'Capítulos semanais atualizados']
      },
      {
        name: 'drive-geral',
        category: 'SUPER PACK - VARIADOS',
        iconType: 'BookOpen',
        badge: 'GIGANTE',
        description: 'Acesso a múltiplos drives compartilhados com Terabytes de conteúdo exclusivo compactado e seguro.',
        valueEstimate: 'R$ 1.500,00+',
        highlights: ['Downloads em alta velocidade', 'Links renovados constantemente']
      },
      {
        name: 'filmes-e-series',
        category: 'SUPER PACK - VARIADOS',
        iconType: 'BookOpen',
        description: 'Canais com dicas e acessos a lançamentos do cinema, séries de streaming e animes em qualidade máxima.',
        valueEstimate: 'R$ 240,00',
        highlights: ['Qualidade 1080p e 4K', 'Sem propagandas irritantes']
      }
    ]
  }
];

export const TOTAL_ESTIMATED_VALUE = 'R$ 16.480,00';
export const TOTAL_CHANNELS_COUNT = 52;
export const TOTAL_CATEGORIES_COUNT = 13;
