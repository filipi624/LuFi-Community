import React, { useState, useMemo } from 'react';
import {
  DISCORD_CATEGORIES,
  DiscordChannel,
  DISCORD_INVITE_URL,
  TOTAL_CHANNELS_COUNT,
} from '../data/discordChannels';
import {
  Search,
  Hash,
  Lock,
  CheckCircle2,
  ExternalLink,
  ArrowRight,
  Laptop,
  Smartphone,
  TrendingUp,
  Target,
  Flame,
  Video,
  BookOpen,
  Star,
  Tag,
  ShieldCheck
} from 'lucide-react';

interface DiscordChannelsExplorerProps {
  onSelectChannelBuy?: (channelName: string, plan: string) => void;
}

export const DiscordChannelsExplorer: React.FC<DiscordChannelsExplorerProps> = ({
  onSelectChannelBuy,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPack, setSelectedPack] = useState<'all' | 'fornecedores' | 'superpack'>('all');
  const [activeChannel, setActiveChannel] = useState<DiscordChannel>(
    DISCORD_CATEGORIES[0].channels[0]
  );

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Star':
        return <Star className="w-4 h-4 text-amber-400" />;
      case 'Laptop':
        return <Laptop className="w-4 h-4 text-sky-400" />;
      case 'Cpu':
        return <Laptop className="w-4 h-4 text-cyan-400" />;
      case 'Smartphone':
        return <Smartphone className="w-4 h-4 text-emerald-400" />;
      case 'TrendingUp':
        return <TrendingUp className="w-4 h-4 text-indigo-400" />;
      case 'Target':
        return <Target className="w-4 h-4 text-rose-400" />;
      case 'Flame':
        return <Flame className="w-4 h-4 text-orange-400" />;
      case 'Video':
        return <Video className="w-4 h-4 text-violet-400" />;
      case 'BookOpen':
        return <BookOpen className="w-4 h-4 text-amber-300" />;
      default:
        return <Hash className="w-4 h-4 text-slate-400" />;
    }
  };

  const isFornecedores = (catTitle: string) => catTitle.toUpperCase().includes('FORNECEDORES');

  const filteredCategories = useMemo(() => {
    return DISCORD_CATEGORIES.map((cat) => {
      const isForn = isFornecedores(cat.title);

      if (selectedPack === 'fornecedores' && !isForn) return null;
      if (selectedPack === 'superpack' && isForn) return null;

      // Filter by search query
      const matchingChannels = cat.channels.filter(
        (ch) =>
          ch.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          ch.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          cat.title.toLowerCase().includes(searchQuery.toLowerCase())
      );

      if (matchingChannels.length === 0) return null;

      return {
        ...cat,
        channels: matchingChannels,
      };
    }).filter(Boolean) as typeof DISCORD_CATEGORIES;
  }, [searchQuery, selectedPack]);

  const totalMatchingChannels = useMemo(() => {
    return filteredCategories.reduce((acc, cat) => acc + cat.channels.length, 0);
  }, [filteredCategories]);

  const activeIsFornecedores = isFornecedores(activeChannel.category);
  const activePlanName = activeIsFornecedores ? 'Fornecedores' : 'Superpack';

  const handleCta = () => {
    if (onSelectChannelBuy) {
      onSelectChannelBuy(activeChannel.name, activePlanName);
    } else {
      window.open(DISCORD_INVITE_URL, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <section id="salas" className="py-14 md:py-20 relative bg-[#090c14] border-t border-slate-800/80">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-8">
          <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight font-display text-white">
            Salas Oficiais do Discord
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-400">
            Selecione uma sala para ver o conteúdo liberado. Filtre por Fornecedores ou Superpack abaixo:
          </p>
        </div>

        {/* Filter Controls - Responsive with Full Width and Smooth Swipe / Touch */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 mb-6">
          {/* Tabs Container with horizontal touch scroll */}
          <div className="w-full md:w-auto overflow-x-auto touch-pan-x scrollbar-none pb-1">
            <div className="flex items-center gap-2 p-1.5 bg-[#121622] rounded-xl border border-slate-800 w-max min-w-full sm:min-w-0">
              <button
                onClick={() => setSelectedPack('all')}
                className={`px-3.5 py-2 text-xs font-bold rounded-lg whitespace-nowrap shrink-0 transition-all cursor-pointer ${
                  selectedPack === 'all'
                    ? 'bg-slate-700 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Todas as Salas ({TOTAL_CHANNELS_COUNT})
              </button>

              <button
                onClick={() => setSelectedPack('fornecedores')}
                className={`px-3.5 py-2 text-xs font-bold rounded-lg whitespace-nowrap shrink-0 transition-all cursor-pointer ${
                  selectedPack === 'fornecedores'
                    ? 'bg-amber-500 text-white shadow-md'
                    : 'text-amber-400/90 hover:text-amber-300 bg-amber-500/10'
                }`}
              >
                FORNECEDORES (R$ 12 c/ cupom)
              </button>

              <button
                onClick={() => setSelectedPack('superpack')}
                className={`px-3.5 py-2 text-xs font-bold rounded-lg whitespace-nowrap shrink-0 transition-all cursor-pointer ${
                  selectedPack === 'superpack'
                    ? 'bg-cyan-500 text-white shadow-md'
                    : 'text-cyan-400/90 hover:text-cyan-300 bg-cyan-500/10'
                }`}
              >
                SUPERPACK (R$ 32 c/ cupom)
              </button>
            </div>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-64 shrink-0">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar sala ou software..."
              className="w-full bg-[#121622] border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs font-medium text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
          </div>
        </div>

        {/* Discord Mockup Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left: Discord Channels Tree */}
          <div className="lg:col-span-7 bg-[#0c101a] border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col max-h-[580px]">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-cyan-500 to-orange-500 flex items-center justify-center font-black text-white text-xs">
                  LC
                </div>
                <div>
                  <div className="text-xs font-bold text-white">LUFI COMMUNITY</div>
                  <div className="text-[10px] text-slate-400">
                    {totalMatchingChannels} salas encontradas
                  </div>
                </div>
              </div>
              <span className="text-[11px] font-mono font-semibold text-emerald-400">
                Acesso Vitalício
              </span>
            </div>

            {/* Scrollable list of channels */}
            <div className="overflow-y-auto pr-1 space-y-4 scrollbar-thin scrollbar-thumb-slate-800">
              {filteredCategories.map((category) => (
                <div key={category.id} className="space-y-1">
                  <div className="flex items-center gap-2 px-2 py-1 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    {getCategoryIcon(category.icon)}
                    <span>{category.title}</span>
                  </div>

                  <div className="space-y-0.5">
                    {category.channels.map((channel) => {
                      const isSelected = activeChannel.name === channel.name;
                      return (
                        <button
                          key={channel.name}
                          onClick={() => setActiveChannel(channel)}
                          className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-cyan-500/15 border border-cyan-500/40 text-cyan-200'
                              : 'text-slate-300 hover:bg-slate-800/50 hover:text-white border border-transparent'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <Hash
                              className={`w-3.5 h-3.5 shrink-0 ${
                                isSelected ? 'text-cyan-400' : 'text-slate-500'
                              }`}
                            />
                            <span className="text-xs font-medium font-mono truncate">
                              • {channel.name}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 shrink-0 ml-2">
                            {channel.badge && (
                              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-400">
                                {channel.badge}
                              </span>
                            )}
                            <Lock
                              className={`w-3 h-3 ${
                                isSelected ? 'text-cyan-400' : 'text-slate-600'
                              }`}
                            />
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Active Channel Details */}
          <div className="lg:col-span-5 bg-[#0e1320] border border-cyan-500/30 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
                {activeChannel.category}
              </span>
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded font-mono ${
                  activeIsFornecedores
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                }`}
              >
                {activeIsFornecedores ? 'Pack Fornecedores' : 'Superpack'}
              </span>
            </div>

            <h3 className="text-xl sm:text-2xl font-black text-white font-mono flex items-center gap-2 mb-3">
              <span className="text-cyan-400">#</span>
              <span>• {activeChannel.name}</span>
            </h3>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-5">
              {activeChannel.description}
            </p>

            {/* What's inside */}
            <div className="space-y-2 mb-5 pb-5 border-b border-slate-800">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Conteúdo liberado nesta sala:
              </div>
              {activeChannel.highlights.map((h, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-slate-200">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                  <span>{h}</span>
                </div>
              ))}
            </div>

            {/* Price Box with Coupon Callout */}
            <div className="mb-5 p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
              {activeIsFornecedores ? (
                <div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Preço padrão: <span className="line-through font-mono">R$ 39,00</span></span>
                    <span className="text-emerald-400 font-bold font-mono">Cupom 27off</span>
                  </div>
                  <div className="flex items-baseline justify-between mt-0.5">
                    <span className="text-xs text-emerald-400 font-bold">Com cupom 27off:</span>
                    <span className="text-2xl font-black text-emerald-400 font-mono">
                      R$ 12,00 <span className="text-xs text-slate-400 font-normal">vitalício</span>
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    Ganhe R$ 27 de desconto usando o cupom no Discord
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Preço padrão: <span className="line-through font-mono">R$ 59,00</span></span>
                    <span className="text-emerald-400 font-bold font-mono">Cupom 27off</span>
                  </div>
                  <div className="flex items-baseline justify-between mt-0.5">
                    <span className="text-xs text-emerald-400 font-bold">Com cupom 27off:</span>
                    <span className="text-2xl font-black text-emerald-400 font-mono">
                      R$ 32,00 <span className="text-xs text-slate-400 font-normal">vitalício</span>
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    Ganhe R$ 27 de desconto usando o cupom no Discord
                  </div>
                </div>
              )}
            </div>

            {/* Direct Action Button */}
            <button
              onClick={handleCta}
              className={`w-full py-3.5 px-6 rounded-xl font-extrabold uppercase tracking-wider text-xs sm:text-sm text-white shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeIsFornecedores
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 shadow-orange-950/40'
                  : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 shadow-cyan-950/40'
              }`}
            >
              <span>
                {activeIsFornecedores
                  ? 'Comprar Fornecedores (R$ 12 c/ 27off)'
                  : 'Comprar Superpack (R$ 32 c/ 27off)'}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="mt-3.5 pt-3 border-t border-slate-800/80 flex items-center justify-center gap-1.5 text-[11px] text-slate-400 text-center">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span>
                Vendas feitas pelo bot da <strong className="text-cyan-300">CENTRAL CART</strong> · Plataforma de pagamentos segura
              </span>
            </div>

            <p className="text-[10px] text-slate-500 text-center mt-2 font-mono">
              Link de redirecionamento: {DISCORD_INVITE_URL}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
