import React, { useState } from 'react';
import { DISCORD_INVITE_URL } from '../data/discordChannels';
import { Check, ShieldCheck, Flame, ExternalLink, Zap, Tag, Copy, Sparkles, CheckCircle2 } from 'lucide-react';

interface PricingSectionProps {
  onOpenCheckoutModal?: () => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onOpenCheckoutModal }) => {
  const [couponApplied, setCouponApplied] = useState(true);
  const [copiedCoupon, setCopiedCoupon] = useState(false);

  const handleCopyCoupon = () => {
    navigator.clipboard.writeText('27off');
    setCopiedCoupon(true);
    setTimeout(() => setCopiedCoupon(false), 2500);
  };

  const handleBuy = (planName: string) => {
    if (onOpenCheckoutModal) {
      onOpenCheckoutModal();
    } else {
      window.open(DISCORD_INVITE_URL, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <section id="planos" className="py-24 bg-gradient-to-b from-[#0a0d15] via-[#080b12] to-[#07090e] relative overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[550px] bg-gradient-to-r from-cyan-600/10 via-sky-600/5 to-orange-500/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 mb-3">
            <span className="text-cyan-400 uppercase tracking-wider">Acessos Separados ou Combo</span>
            <span aria-hidden="true">·</span>
            <span className="text-orange-400 font-bold">Cupom 27off Ativo</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white font-display text-balance">
            Escolha o Seu Acesso na LUFI COMMUNITY
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-400">
            Os acessos de <strong>Fornecedores</strong> e do <strong>Super Pack</strong> são separados para você pagar apenas pelo que precisa. Ou leve o Combo Completo com todos os 52 canais!
          </p>
        </div>

        {/* Interactive Coupon Box */}
        <div className="max-w-2xl mx-auto mb-14 bg-gradient-to-r from-orange-950/40 via-amber-950/30 to-cyan-950/40 border border-orange-500/40 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/20 border border-orange-500/40 flex items-center justify-center text-orange-400 shrink-0">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-orange-300 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <span>Cupom Promocional de R$ 27 OFF</span>
                <span className="px-1.5 py-0.2 text-[10px] bg-emerald-500/20 text-emerald-300 rounded font-mono font-bold">
                  ATIVADO
                </span>
              </div>
              <div className="text-sm font-semibold text-white">
                Use <code className="bg-black/60 px-2 py-0.5 rounded text-amber-300 font-mono text-xs border border-orange-500/30">27off</code> e pague de <span className="line-through text-slate-400">R$ 59</span> por apenas <strong className="text-emerald-400 font-mono text-base">R$ 32</strong>!
              </div>
            </div>
          </div>

          <button
            onClick={handleCopyCoupon}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-400 text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-orange-950/60 active:scale-95 transition-all shrink-0"
          >
            {copiedCoupon ? (
              <>
                <Check className="w-4 h-4 text-white" />
                <span>Cupom 27off Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copiar Cupom</span>
              </>
            )}
          </button>
        </div>

        {/* Pricing Cards Grid (3 Columns) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {/* Plan 1: Apenas Fornecedores */}
          <div className="bg-[#0b0f1a] border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-xl hover:border-amber-500/40 transition-all duration-300">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                  Acesso Separado
                </span>
                <span className="text-[11px] px-2.5 py-1 rounded bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30">
                  15 Canais
                </span>
              </div>

              <h3 className="text-2xl font-black text-white font-display">
                Pack Fornecedores
              </h3>
              <p className="text-xs text-slate-400 mt-2">
                Atacado físico direto da fábrica e fornecedores de contas/ativos digitais.
              </p>

              {/* Price Box */}
              <div className="my-6 p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>No mercado avulso:</span>
                  <span className="line-through text-rose-400 font-mono font-medium">R$ 1.200,00+</span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Preço padrão:</span>
                  <span className="line-through text-slate-400 font-mono">R$ 59,00</span>
                </div>
                <div className="pt-2 border-t border-slate-800 flex items-baseline justify-between">
                  <span className="text-xs font-bold text-emerald-400">Com cupom 27off:</span>
                  <div className="text-right">
                    <span className="text-3xl font-black text-white font-mono">R$ 32</span>
                    <span className="text-xs text-slate-400 font-mono">,00</span>
                  </div>
                </div>
                <div className="text-[10px] text-emerald-400 font-mono text-right">
                  Desconto imediato de R$ 27,00
                </div>
              </div>

              {/* Channel list highlights */}
              <div className="space-y-2.5 text-xs text-slate-300 mb-6">
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Roupas Streetwear & Grifes direto da fábrica</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Eletrônicos, iPhones lacrados e vitrine</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Tênis importados primeira linha (Nike, Jordan)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Perfumes importados, joias e relógios atacado</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Marketplaces globais, chaves Windows/Office</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Roblox Robux barato, painéis SMM, GGsel</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleBuy('Pack Fornecedores')}
              className="w-full py-3.5 px-5 rounded-xl font-bold uppercase tracking-wider text-xs text-white bg-slate-800 hover:bg-slate-700 hover:border-amber-500/50 border border-slate-700 transition-all flex items-center justify-center gap-2"
            >
              <span>Pegar Fornecedores por R$ 32</span>
              <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
            </button>
          </div>

          {/* Plan 2: Apenas Super Pack */}
          <div className="bg-[#0b0f1a] border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-xl hover:border-cyan-500/40 transition-all duration-300">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">
                  Acesso Separado
                </span>
                <span className="text-[11px] px-2.5 py-1 rounded bg-cyan-500/15 text-cyan-300 font-semibold border border-cyan-500/30">
                  37 Canais
                </span>
              </div>

              <h3 className="text-2xl font-black text-white font-display">
                Super Pack Completo
              </h3>
              <p className="text-xs text-slate-400 mt-2">
                Softwares com licença vitalícia, aplicativos, tráfego, automações e drives.
              </p>

              {/* Price Box */}
              <div className="my-6 p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>No mercado avulso:</span>
                  <span className="line-through text-rose-400 font-mono font-medium">R$ 3.380,00+</span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Preço padrão:</span>
                  <span className="line-through text-slate-400 font-mono">R$ 59,00</span>
                </div>
                <div className="pt-2 border-t border-slate-800 flex items-baseline justify-between">
                  <span className="text-xs font-bold text-emerald-400">Com cupom 27off:</span>
                  <div className="text-right">
                    <span className="text-3xl font-black text-white font-mono">R$ 32</span>
                    <span className="text-xs text-slate-400 font-mono">,00</span>
                  </div>
                </div>
                <div className="text-[10px] text-emerald-400 font-mono text-right">
                  Desconto imediato de R$ 27,00
                </div>
              </div>

              {/* Channel list highlights */}
              <div className="space-y-2.5 text-xs text-slate-300 mb-6">
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>WA Sender vitalício (disparador em massa)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Zap Voice vitalício (envia áudio na hora)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Typerbot, fluxos n8n prontos e clonador de páginas</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>IPTV vitalício e extensões de espionagem</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Tráfego pago/orgânico, páginas prontas e PLRs</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Cortes virais, Canva Tudo, livros e mega drives</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleBuy('Super Pack')}
              className="w-full py-3.5 px-5 rounded-xl font-bold uppercase tracking-wider text-xs text-white bg-slate-800 hover:bg-slate-700 hover:border-cyan-500/50 border border-slate-700 transition-all flex items-center justify-center gap-2"
            >
              <span>Pegar Super Pack por R$ 32</span>
              <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
            </button>
          </div>

          {/* Plan 3: Combo Completo Tudo Liberado */}
          <div className="relative rounded-3xl p-1 bg-gradient-to-b from-cyan-500 via-sky-500 to-orange-500 shadow-2xl shadow-cyan-950/60 flex flex-col justify-between">
            <div className="bg-[#0c101d] rounded-[22px] p-6 sm:p-8 h-full flex flex-col justify-between relative overflow-hidden">
              {/* Corner badge */}
              <div className="absolute top-0 right-0 bg-gradient-to-l from-orange-500 to-amber-500 text-white text-[11px] font-black uppercase tracking-wider px-4 py-1.5 rounded-bl-xl shadow-md">
                TUDO LIBERADO
              </div>

              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-orange-400 uppercase tracking-widest">
                    Combo Definitivo
                  </span>
                  <span className="text-[11px] px-2.5 py-1 rounded bg-orange-500/20 text-orange-300 font-bold border border-orange-500/30">
                    52 Canais
                  </span>
                </div>

                <h3 className="text-2xl font-black text-white font-display">
                  Fornecedores + Super Pack
                </h3>
                <p className="text-xs text-slate-300 mt-2">
                  O arsenal completo da LUFI COMMUNITY. Nada fica trancado, acesso vitalício total.
                </p>

                {/* Price Box */}
                <div className="my-6 p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/40 space-y-1">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>No mercado individual:</span>
                    <span className="line-through text-rose-400 font-mono font-medium">R$ 4.580,00+</span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>Os 2 packs juntos:</span>
                    <span className="line-through text-slate-400 font-mono">R$ 118,00</span>
                  </div>
                  <div className="pt-2 border-t border-slate-800 flex items-baseline justify-between">
                    <span className="text-xs font-bold text-cyan-300">Condição no Discord:</span>
                    <div className="text-right">
                      <span className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-orange-400 font-mono">
                        R$ 59
                      </span>
                      <span className="text-xs text-slate-400 font-mono">,00</span>
                    </div>
                  </div>
                  <div className="text-[10px] text-orange-400 font-mono text-right">
                    Leve os 2 pelo preço de 1 com cupom 27off!
                  </div>
                </div>

                {/* Checklist */}
                <div className="space-y-2.5 text-xs text-slate-200 mb-6">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span><strong>Todos os 52 canais</strong> liberados imediatamente</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span>Todos os contatos de fornecedores de atacado</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span>Todos os softwares e disparadores vitalícios</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span>Páginas de vendas, automações e robôs</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0" />
                    <span>Atualizações semanais gratuitas para sempre</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0" />
                    <span>Suporte VIP prioritário no servidor</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => handleBuy('Combo Completo')}
                className="w-full py-4 px-6 rounded-xl font-extrabold uppercase tracking-wider text-xs sm:text-sm text-white bg-gradient-to-r from-cyan-500 via-sky-600 to-orange-500 hover:from-cyan-400 hover:to-orange-400 shadow-xl shadow-cyan-950/60 hover:shadow-cyan-500/25 transition-all flex items-center justify-center gap-2 active:scale-98"
              >
                <span>Garantir Combo Completo no Discord</span>
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Security and Method Footer */}
        <div className="mt-12 text-center text-xs text-slate-400 flex items-center justify-center flex-wrap gap-4">
          <div className="flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>Liberação instantânea no Discord</span>
          </div>
          <span aria-hidden="true">·</span>
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Acesso vitalício sem cobranças recorrentes</span>
          </div>
          <span aria-hidden="true">·</span>
          <div className="flex items-center gap-1.5">
            <Tag className="w-4 h-4 text-orange-400" />
            <span>Cupom <strong className="text-white font-mono">27off</strong> válido por tempo limitado</span>
          </div>
        </div>
      </div>
    </section>
  );
};
