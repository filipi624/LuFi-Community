import React, { useState, useEffect } from 'react';
import { LufiLogo } from './LufiLogo';
import { DISCORD_INVITE_URL } from '../data/discordChannels';
import { ExternalLink, Menu, X } from 'lucide-react';

interface NavbarProps {
  onOpenCheckoutModal?: (plan?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenCheckoutModal }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleCtaClick = () => {
    if (onOpenCheckoutModal) {
      onOpenCheckoutModal();
    } else {
      window.open(DISCORD_INVITE_URL, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#07090e]/95 backdrop-blur-md border-b border-slate-800/80 shadow-xl py-3'
            : 'bg-[#07090e]/70 backdrop-blur-sm py-4 border-b border-white/5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-8">
            {/* Zone 1: Brand title */}
            <a
              href="#"
              className="inline-flex items-center whitespace-nowrap shrink-0 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 rounded-lg"
            >
              <LufiLogo size="sm" />
            </a>

            {/* Zone 2: Simple clean nav links */}
            <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
              <a
                href="#inicio"
                className="hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0"
              >
                Início
              </a>
              <a
                href="#salas"
                className="hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0"
              >
                Salas do Discord
              </a>
              <a
                href="#precos"
                className="hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0"
              >
                Preços
              </a>
            </nav>

            {/* Zone 3: 1 primary action */}
            <div className="hidden sm:flex items-center gap-3 shrink-0">
              <button
                onClick={handleCtaClick}
                className="group inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-bold tracking-wide uppercase text-white bg-gradient-to-r from-cyan-500 via-sky-600 to-orange-500 hover:from-cyan-400 hover:to-orange-400 rounded-xl transition-all duration-200 shadow-lg shadow-cyan-950/40 active:scale-95 whitespace-nowrap shrink-0"
              >
                <span>Acessar Discord</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Mobile Hamburger toggle */}
            <div className="flex md:hidden items-center gap-2">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label="Abrir menu"
                className="p-2 text-slate-300 hover:text-white rounded-lg bg-slate-900 border border-slate-800"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-black/90 backdrop-blur-md md:hidden pt-24 px-6 flex flex-col gap-6">
          <nav className="flex flex-col gap-4 text-base font-medium text-slate-200">
            <a
              href="#inicio"
              onClick={() => setMobileMenuOpen(false)}
              className="py-3 border-b border-slate-800 hover:text-cyan-400"
            >
              Início
            </a>
            <a
              href="#salas"
              onClick={() => setMobileMenuOpen(false)}
              className="py-3 border-b border-slate-800 hover:text-cyan-400"
            >
              Salas do Discord
            </a>
            <a
              href="#precos"
              onClick={() => setMobileMenuOpen(false)}
              className="py-3 border-b border-slate-800 hover:text-cyan-400"
            >
              Preços (Superpack R$ 32 / Fornecedores R$ 12 c/ cupom)
            </a>
          </nav>

          <button
            onClick={() => {
              setMobileMenuOpen(false);
              handleCtaClick();
            }}
            className="w-full flex items-center justify-center gap-2 py-3.5 px-6 text-sm font-bold uppercase tracking-wider text-white bg-gradient-to-r from-cyan-600 to-orange-500 rounded-xl shadow-lg"
          >
            <span>Entrar no Discord</span>
            <ExternalLink className="w-4 h-4" />
          </button>
        </div>
      )}
    </>
  );
};
