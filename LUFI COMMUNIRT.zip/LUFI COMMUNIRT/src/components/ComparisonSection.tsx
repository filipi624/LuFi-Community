import React from 'react';
import { DISCORD_INVITE_URL } from '../data/discordChannels';
import { XCircle, CheckCircle2, ArrowRight, ShieldCheck, Flame } from 'lucide-react';

interface ComparisonSectionProps {
  onOpenCheckoutModal?: () => void;
}

export const ComparisonSection: React.FC<ComparisonSectionProps> = ({ onOpenCheckoutModal }) => {
  const handleCta = () => {
    if (onOpenCheckoutModal) {
      onOpenCheckoutModal();
    } else {
      window.open(DISCORD_INVITE_URL, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <section className="py-20 bg-[#0a0d15] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 mb-3">
            <span className="text-orange-400 uppercase tracking-wider">Custo vs Benefício</span>
            <span aria-hidden="true">·</span>
            <span>Transparência Total</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white font-display text-balance">
            A Matemática é Simples: Pare de Pagar Mensalidades Absurdas
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-400">
            Veja quanto você gastaria para ter acesso aos mesmos recursos comprando de forma avulsa
            na internet.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch max-w-5xl mx-auto">
          {/* Card Comprando Separado */}
          <div className="bg-[#0f131f] border border-rose-900/30 rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-xl">
            <div>
              <div className="flex items-center justify-between mb-4 pb-4 border-b border-slate-800">
                <div>
                  <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">
                    Opção Tradicional
                  </span>
                  <h3 className="text-xl font-bold text-slate-200">Comprar Tudo Avulso</h3>
                </div>
                <XCircle className="w-6 h-6 text-rose-500" />
              </div>

              <div className="space-y-3 text-xs sm:text-sm text-slate-400">
                <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
                  <span>Licenças de disparo WhatsApp (WA Sender)</span>
                  <span className="text-slate-300 font-mono">R$ 497,00</span>
                </div>
                <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
                  <span>Software de áudio humanizado (Zap Voice)</span>
                  <span className="text-slate-300 font-mono">R$ 397,00/ano</span>
                </div>
                <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
                  <span>Listas e contatos de fornecedores de atacado</span>
                  <span className="text-slate-300 font-mono">R$ 450,00</span>
                </div>
                <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
                  <span>Automações prontas n8n & chatbots</span>
                  <span className="text-slate-300 font-mono">R$ 597,00</span>
                </div>
                <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
                  <span>Cursos de marketing, tráfego e vendas</span>
                  <span className="text-slate-300 font-mono">R$ 1.997,00+</span>
                </div>
                <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
                  <span>Templates de páginas & clonadores</span>
                  <span className="text-slate-300 font-mono">R$ 350,00</span>
                </div>
                <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
                  <span>Packs de Canva, design e vídeos virais</span>
                  <span className="text-slate-300 font-mono">R$ 297,00</span>
                </div>
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-slate-800">
              <div className="text-xs text-slate-400">Gasto total estimado:</div>
              <div className="text-2xl font-black text-rose-400 font-mono line-through">
                R$ 4.585,00+
              </div>
              <p className="text-xs text-slate-400 mt-2">
                Mais de R$ 4.000 em gastos individuais e dezenas de renovações mensais para manter.
              </p>
            </div>
          </div>

          {/* Card LUFI COMMUNITY */}
          <div className="bg-gradient-to-b from-[#111728] via-[#0d1322] to-[#0a0f1c] border-2 border-cyan-500/50 rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl relative overflow-hidden">
            {/* Top Badge */}
            <div className="absolute top-0 right-0 bg-gradient-to-l from-orange-500 to-amber-500 text-white text-[11px] font-black uppercase tracking-wider px-4 py-1.5 rounded-bl-xl shadow-md">
              Melhor Escolha
            </div>

            <div>
              <div className="flex items-center justify-between mb-4 pb-4 border-b border-slate-800">
                <div>
                  <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                    Acesso Completo
                  </span>
                  <h3 className="text-xl sm:text-2xl font-extrabold text-white font-display">
                    LUFI COMMUNITY VIP
                  </h3>
                </div>
                <CheckCircle2 className="w-7 h-7 text-cyan-400" />
              </div>

              <div className="space-y-3 text-xs sm:text-sm text-slate-200">
                <div className="flex items-center gap-2.5 py-1">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Todos os 52 canais do Discord 100% desbloqueados</span>
                </div>
                <div className="flex items-center gap-2.5 py-1">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Softwares com versão vitalícia sem pagar mensalidade</span>
                </div>
                <div className="flex items-center gap-2.5 py-1">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Contatos diretos de fornecedores validados de fábrica</span>
                </div>
                <div className="flex items-center gap-2.5 py-1">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Páginas de vendas prontas, copys e funis de conversão</span>
                </div>
                <div className="flex items-center gap-2.5 py-1">
                  <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0" />
                  <span>Acesso Vitalício: paga uma única vez e nunca mais</span>
                </div>
                <div className="flex items-center gap-2.5 py-1">
                  <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0" />
                  <span>Atualizações semanais gratuitas com novas ferramentas</span>
                </div>
                <div className="flex items-center gap-2.5 py-1">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Suporte e comunidade ativa no Discord</span>
                </div>
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-slate-800/80">
              <div className="flex items-baseline justify-between mb-2">
                <span className="text-xs text-slate-400">Preço Padrão: <span className="line-through font-mono">R$ 59,00</span></span>
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                  CUPOM 27off (-R$ 27)
                </span>
              </div>
              <div className="text-3xl sm:text-4xl font-black text-white font-mono flex items-baseline gap-2">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-orange-400">
                  R$ 32,00
                </span>
                <span className="text-xs text-slate-400 font-normal">por pack</span>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                Acessos separados (Pack Fornecedores ou Super Pack) por R$ 32 cada com o cupom, ou combo com ambos no Discord.
              </p>

              <button
                onClick={handleCta}
                className="w-full mt-5 py-3.5 px-6 rounded-xl text-xs sm:text-sm font-extrabold uppercase tracking-wider text-white bg-gradient-to-r from-cyan-500 via-sky-600 to-orange-500 hover:from-cyan-400 hover:to-orange-400 shadow-xl shadow-cyan-950/50 hover:shadow-cyan-500/25 transition-all flex items-center justify-center gap-2"
              >
                <span>Aproveitar por R$ 32 no Discord</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
