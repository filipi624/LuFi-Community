import React, { useState } from 'react';
import { ChevronDown, HelpCircle, ExternalLink } from 'lucide-react';
import { DISCORD_INVITE_URL } from '../data/discordChannels';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Quanto custa e como funciona o cupom 27off?',
      a: 'O valor padrão de cada acesso na comunidade é R$ 59,00. Utilizando o cupom "27off", você ganha R$ 27,00 de desconto imediato e paga apenas R$ 32,00 por um acesso vitalício! Basta enviar o cupom 27off no chat ou abrir um ticket no nosso servidor do Discord.'
    },
    {
      q: 'Os fornecedores e o Super Pack são separados?',
      a: 'Sim! Para que você pague um valor super acessível e apenas pelo que realmente vai utilizar, separamos em: 1) Pack Fornecedores (com todos os contatos de atacado físico de roupas, eletrônicos, tênis, perfumes e digital) e 2) Super Pack (softwares vitalícios como WA Sender e Zap Voice, aplicativos, automações n8n, tráfego pago e cursos). Cada um sai por apenas R$ 32 com o cupom 27off. E se quiser ambos, temos o Combo Completo com desconto adicional no Discord!'
    },
    {
      q: 'Como recebo meu acesso após clicar em comprar?',
      a: 'Ao clicar no botão de compra ou no link do Discord (https://discord.gg/uwWEa7DrcJ), você será redirecionado para o nosso servidor oficial da LUFI COMMUNITY. Lá você terá o canal de atendimento e checkout com nossa equipe, onde o cargo VIP é atribuído imediatamente à sua conta do Discord, desbloqueando seus canais na hora.'
    },
    {
      q: 'O acesso é realmente vitalício ou tem cobrança anual?',
      a: 'É 100% vitalício! Não existe mensalidade, anuidade ou taxa oculta. Uma vez dentro da comunidade, você tem direito ao acervo para sempre, incluindo todas as novidades e atualizações que forem lançadas.'
    },
    {
      q: 'O que está incluso na LUFI COMMUNITY?',
      a: 'Você terá acesso a absolutamente todos os canais do seu plano: fornecedores de atacado (tênis, roupas de grife, eletrônicos, perfumes), fornecedores digitais (chaves de software, Robux, SMM), softwares vitalícios (WA Sender, Zap Voice, clonador de páginas, typerbot, fluxos n8n), aplicativos (IPTV vitalício, extensões), tráfego pago, marketing digital, PLRs, vídeos virais e mega drives compartilhados.'
    },
    {
      q: 'Preciso ter computador potente ou entender de programação?',
      a: 'Não! Os softwares e ferramentas possuem tutoriais rápidos e passo a passo em vídeo. Softwares como WA Sender, Zap Voice e clonadores rodam tranquilamente no seu computador diário, e boa parte do acervo (fornecedores, drives, livros, vídeos virais e canais) pode ser acessada direto pelo celular.'
    },
    {
      q: 'Novos canais e ferramentas são adicionados com frequência?',
      a: 'Sim! Toda semana nossa equipe minera e adiciona novos fornecedores, scripts atualizados, tendências de tráfego e ferramentas. Você não paga nem um centavo a mais por essas novas adições.'
    }
  ];

  return (
    <section id="faq" className="py-20 bg-[#07090e] relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 mb-3">
            <HelpCircle className="w-4 h-4 text-cyan-400" />
            <span className="text-cyan-400 uppercase tracking-wider">Tire Suas Dúvidas</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-display text-balance">
            Perguntas Frequentes
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-400">
            Tudo o que você precisa saber antes de entrar na comunidade.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="bg-[#0c101c] border border-slate-800/80 rounded-xl overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full flex items-center justify-between p-5 text-left text-sm sm:text-base font-bold text-slate-200 hover:text-white transition-colors"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-cyan-400' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-slate-800/40">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Discord Link Banner */}
        <div className="mt-12 text-center p-6 bg-slate-900/60 border border-slate-800 rounded-2xl">
          <p className="text-xs sm:text-sm text-slate-300 mb-3">
            Ainda com alguma dúvida específica? Fale conosco direto no servidor:
          </p>
          <a
            href={DISCORD_INVITE_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-cyan-400 hover:text-cyan-300 underline underline-offset-4"
          >
            <span>Acessar Discord Oficial (discord.gg/uwWEa7DrcJ)</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </section>
  );
};
