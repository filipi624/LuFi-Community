import React from 'react';
import { DISCORD_INVITE_URL } from '../data/discordChannels';
import { Star, MessageSquareQuote, CheckCircle2, ExternalLink } from 'lucide-react';

interface TestimonialsSectionProps {
  onOpenCheckoutModal?: () => void;
}

export const TestimonialsSection: React.FC<TestimonialsSectionProps> = ({ onOpenCheckoutModal }) => {
  const testimonials = [
    {
      author: 'Lucas Medeiros',
      role: 'Membro VIP',
      avatarColor: 'from-cyan-500 to-blue-600',
      initials: 'LM',
      tag: '#fornecedores-eletrônico',
      text: 'Peguei o contato de fornecedor de iPhone de vitrine e lacrado direto no canal de atacado. Fiz meu primeiro pedido de teste com 3 aparelhos e chegou certinho com nota e rastreio. Margem de lucro limpa de 42% na revenda.',
      channel: 'eletrônico'
    },
    {
      author: 'Gabriel Santos',
      role: 'Operador de Tráfego',
      avatarColor: 'from-orange-500 to-amber-600',
      initials: 'GS',
      tag: '#wa-sender-vitalicio',
      text: 'O WA Sender e o Zap Voice vitalício sozinhos valem mais de mil reais. Eu pagava R$ 197 por mês em outro disparador que vivia dando erro. Aqui configurei em 5 minutos e já estou rodando disparos diários sem mensalidade.',
      channel: 'softwares'
    },
    {
      author: 'Felipe Rocha',
      role: 'Criador de Conteúdo',
      avatarColor: 'from-sky-500 to-indigo-600',
      initials: 'FR',
      tag: '#cortes-gerais & canva',
      text: 'O acervo de cortes virais e os templates do Canva Tudo me pouparam semanas de produção. Subi 2 canais dark no TikTok e no Reels usando as mídias da comunidade e já estou monetizado em um deles.',
      channel: 'vídeos-virais'
    },
    {
      author: 'Matheus Alencar',
      role: 'Afiliado & Dropshipping',
      avatarColor: 'from-emerald-500 to-teal-600',
      initials: 'MA',
      tag: '#paginas-de-vendas-prontas',
      text: 'Clonador de páginas e as VSLs prontas facilitaram demais a minha operação. Quando vejo uma página gringa boa, baixo em segundos e adapto para o mercado brasileiro. Acesso vitalício que realmente entrega o que promete.',
      channel: 'marketing'
    }
  ];

  const handleCta = () => {
    if (onOpenCheckoutModal) {
      onOpenCheckoutModal();
    } else {
      window.open(DISCORD_INVITE_URL, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <section className="py-20 bg-[#07090e] border-t border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 mb-3">
            <span className="text-cyan-400 uppercase tracking-wider">Comunidade Ativa</span>
            <span aria-hidden="true">·</span>
            <span>Membros Reais</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-display text-balance">
            Quem Entra na LUFI COMMUNITY Não Volta a Pagar Mensalidade
          </h2>
          <p className="mt-4 text-sm sm:text-base text-slate-400">
            Veja o que os membros dizem sobre o acervo, a qualidade dos fornecedores e as ferramentas
            liberadas no Discord.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((item, idx) => (
            <div
              key={idx}
              className="bg-[#0c101c] border border-slate-800/90 rounded-2xl p-6 flex flex-col justify-between hover:border-slate-700 transition-colors shadow-lg"
            >
              <div>
                {/* Discord-style message header */}
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className={`w-10 h-10 rounded-full bg-gradient-to-br ${item.avatarColor} flex items-center justify-center font-bold text-white text-xs shadow-md`}
                  >
                    {item.initials}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>{item.author}</span>
                      <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">{item.role}</div>
                  </div>
                </div>

                <div className="text-[11px] font-mono text-cyan-400/90 mb-3 flex items-center gap-1">
                  <span>{item.tag}</span>
                </div>

                <p className="text-xs sm:text-[13px] text-slate-300 leading-relaxed">
                  &ldquo;{item.text}&rdquo;
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-800/60 flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Call to join the chat */}
        <div className="mt-12 text-center">
          <button
            onClick={handleCta}
            className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-300 hover:text-white group"
          >
            <span>Conheça os membros e troque networking no servidor oficial</span>
            <ExternalLink className="w-4 h-4 text-cyan-400 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
};
