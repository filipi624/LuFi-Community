import React, { useState } from 'react';
import { DISCORD_INVITE_URL } from '../data/discordChannels';
import { LufiLogo } from './LufiLogo';
import { X, ExternalLink, Copy, Check, ShieldCheck } from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  planName?: string;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  planName,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCoupon, setCopiedCoupon] = useState(false);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(DISCORD_INVITE_URL);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCopyCoupon = () => {
    navigator.clipboard.writeText('27off');
    setCopiedCoupon(true);
    setTimeout(() => setCopiedCoupon(false), 2500);
  };

  const handleOpenDiscord = () => {
    window.open(DISCORD_INVITE_URL, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-md bg-[#0d121e] border border-cyan-500/40 rounded-2xl p-6 shadow-2xl shadow-cyan-950/80"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg bg-slate-900 border border-slate-800 transition-colors cursor-pointer"
          aria-label="Fechar"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="text-center mb-5">
          <LufiLogo size="md" className="justify-center mb-2" />
          <h3 className="text-xl font-black text-white font-display">
            {planName ? `Comprar ${planName}` : 'Acessar Discord Oficial'}
          </h3>
          <p className="text-xs text-slate-300 mt-1">
            {planName === 'Fornecedores'
              ? 'Fornecedores: De R$ 39 por apenas R$ 12 c/ cupom 27off'
              : planName === 'Superpack'
              ? 'Superpack: De R$ 59 por apenas R$ 32 c/ cupom 27off'
              : 'Superpack R$ 32 · Fornecedores R$ 12 com cupom 27off'}
          </p>
        </div>

        {/* Coupon Box */}
        <div className="mb-4 p-3 rounded-xl bg-orange-950/40 border border-orange-500/40 flex items-center justify-between gap-2">
          <div>
            <div className="text-[11px] text-orange-300 font-bold uppercase tracking-wider flex items-center gap-1.5">
              <span>Cupom Ativo:</span>
              <span className="font-mono text-xs bg-black/70 text-amber-300 px-2 py-0.5 rounded border border-orange-500/40 font-bold">
                27off
              </span>
            </div>
            <div className="text-[11px] text-slate-300 mt-0.5">
              Fornecedores por <strong className="text-emerald-400 font-bold">R$ 12</strong> ou Superpack por <strong className="text-emerald-400 font-bold">R$ 32</strong>!
            </div>
          </div>
          <button
            onClick={handleCopyCoupon}
            className="px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-400 text-white text-[11px] font-bold uppercase transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
          >
            {copiedCoupon ? (
              <>
                <Check className="w-3.5 h-3.5 text-white" />
                <span>Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copiar</span>
              </>
            )}
          </button>
        </div>

        {/* Central Cart Callout Banner */}
        <div className="mb-4 p-3 bg-gradient-to-r from-blue-950/50 to-indigo-950/50 border border-cyan-500/30 rounded-xl flex items-start gap-2.5">
          <div className="w-6 h-6 rounded bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0 mt-0.5 font-bold text-xs">
            ⚡
          </div>
          <div className="text-[11px] text-slate-300 leading-snug">
            <span className="font-bold text-cyan-300">Vendas via CENTRAL CART:</span> Nossas vendas são feitas pelo sistema de bot da <strong>CENTRAL CART</strong>, uma plataforma de pagamentos automatizada e segura no Discord.
          </div>
        </div>

        {/* Steps */}
        <div className="space-y-2.5 mb-5 bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 text-xs text-slate-300">
          <div className="flex items-center gap-2.5">
            <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center shrink-0">
              1
            </span>
            <span>Clique no botão abaixo para entrar no Discord oficial.</span>
          </div>
          <div className="flex items-center gap-2.5">
            <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center shrink-0">
              2
            </span>
            <span>
              No canal de compras, o bot da <strong className="text-cyan-300 font-bold">CENTRAL CART</strong> gera seu Pix ou Cartão. Use o cupom <strong className="text-amber-300">27off</strong>.
            </span>
          </div>
          <div className="flex items-center gap-2.5">
            <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0">
              3
            </span>
            <span>
              O bot entrega seu cargo VIP e libera as salas no mesmo segundo após o pagamento!
            </span>
          </div>
        </div>

        {/* Big Action Button */}
        <button
          onClick={handleOpenDiscord}
          className="w-full py-3.5 px-6 rounded-xl font-bold uppercase tracking-wider text-sm text-white bg-gradient-to-r from-cyan-500 via-sky-600 to-orange-500 hover:from-cyan-400 hover:to-orange-400 shadow-xl transition-all flex items-center justify-center gap-2 mb-3 active:scale-98 cursor-pointer"
        >
          <span>Ir Para o Discord Agora</span>
          <ExternalLink className="w-4 h-4" />
        </button>

        {/* Copy Link */}
        <div className="flex items-center gap-2 p-1.5 rounded-lg bg-slate-950 border border-slate-800 mb-3">
          <input
            type="text"
            readOnly
            value={DISCORD_INVITE_URL}
            className="bg-transparent text-xs text-slate-400 font-mono flex-1 outline-none px-2"
          />
          <button
            onClick={handleCopyLink}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors cursor-pointer"
          >
            {copiedLink ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">Copiado</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 text-slate-400" />
                <span>Copiar</span>
              </>
            )}
          </button>
        </div>

        <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400 text-center">
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <span>Vendas seguras com bot da <strong className="text-cyan-300">CENTRAL CART</strong> (Plataforma de Pagamentos)</span>
        </div>
      </div>
    </div>
  );
};
