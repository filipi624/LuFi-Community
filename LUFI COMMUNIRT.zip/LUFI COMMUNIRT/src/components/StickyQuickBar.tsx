import React, { useState, useEffect } from 'react';
import { DISCORD_INVITE_URL } from '../data/discordChannels';
import { ExternalLink, Sparkles } from 'lucide-react';

interface StickyQuickBarProps {
  onOpenCheckoutModal?: () => void;
}

export const StickyQuickBar: React.FC<StickyQuickBarProps> = ({ onOpenCheckoutModal }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show when scrolled down past hero
      setVisible(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!visible) return null;

  const handleCta = () => {
    if (onOpenCheckoutModal) {
      onOpenCheckoutModal();
    } else {
      window.open(DISCORD_INVITE_URL, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 p-2 sm:p-3 pointer-events-none transition-all duration-300">
      <div className="max-w-4xl mx-auto bg-[#0a0e18]/95 backdrop-blur-md border border-cyan-500/40 rounded-xl p-2.5 sm:px-5 sm:py-3 shadow-2xl shadow-cyan-950/80 pointer-events-auto flex items-center justify-between gap-4">
        {/* Left: Info */}
        <div className="flex items-center gap-3 truncate">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-orange-500 flex items-center justify-center font-black text-white text-xs shrink-0 font-display">
            LC
          </div>
          <div className="truncate">
            <div className="text-xs sm:text-sm font-bold text-white truncate flex items-center gap-1.5">
              <span>LUFI COMMUNITY</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-semibold font-mono">
                Cupom 27off (-R$ 27)
              </span>
            </div>
            <div className="text-[10px] sm:text-xs text-slate-300 truncate">
              De <span className="line-through text-slate-400">R$ 59</span> por apenas <strong className="text-white font-mono font-bold">R$ 32</strong> no Discord
            </div>
          </div>
        </div>

        {/* Right: CTA button */}
        <button
          onClick={handleCta}
          className="shrink-0 flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg text-xs font-extrabold uppercase tracking-wider text-white bg-gradient-to-r from-cyan-500 to-orange-500 hover:from-cyan-400 hover:to-orange-400 shadow-md shadow-cyan-950/40 active:scale-95 transition-all whitespace-nowrap"
        >
          <span>Garantir por R$ 32</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
