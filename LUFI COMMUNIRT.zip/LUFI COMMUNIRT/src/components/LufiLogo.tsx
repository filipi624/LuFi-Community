import React from 'react';

interface LufiLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export const LufiLogo: React.FC<LufiLogoProps> = ({
  className = '',
  size = 'md',
  showText = true,
}) => {
  const sizeMap = {
    sm: { icon: 34, text: 'text-base', sub: 'text-[9px]' },
    md: { icon: 46, text: 'text-xl', sub: 'text-[10px]' },
    lg: { icon: 64, text: 'text-2xl', sub: 'text-xs' },
    xl: { icon: 96, text: 'text-4xl', sub: 'text-sm' },
  };

  const currentSize = sizeMap[size];

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* SVG Icon Emblem */}
      <div className="relative shrink-0 flex items-center justify-center">
        <svg
          width={currentSize.icon}
          height={currentSize.icon}
          viewBox="0 0 200 200"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="drop-shadow-[0_0_16px_rgba(6,182,212,0.35)] transition-transform duration-300 hover:scale-105"
        >
          <defs>
            <linearGradient id="lufiCyanGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="60%" stopColor="#0284c7" />
              <stop offset="100%" stopColor="#0369a1" />
            </linearGradient>

            <linearGradient id="lufiOrangeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fbbf24" />
              <stop offset="50%" stopColor="#f97316" />
              <stop offset="100%" stopColor="#ea580c" />
            </linearGradient>

            <linearGradient id="lufiRingCyan" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#00f2fe" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#4facfe" stopOpacity="0.2" />
            </linearGradient>

            <linearGradient id="lufiRingOrange" x1="100%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ff9a44" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#fc6076" stopOpacity="0.2" />
            </linearGradient>

            <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Background circle depth */}
          <circle cx="100" cy="100" r="86" fill="#0b0e14" stroke="#1e293b" strokeWidth="2" />

          {/* Outer Orbit Glowing Arcs */}
          {/* Top-Right Orange Arc */}
          <path
            d="M 100 18 A 82 82 0 0 1 182 100"
            stroke="url(#lufiOrangeGrad)"
            strokeWidth="5"
            strokeLinecap="round"
            filter="url(#neonGlow)"
          />
          {/* Bottom-Left Cyan Arc */}
          <path
            d="M 100 182 A 82 82 0 0 1 18 100"
            stroke="url(#lufiCyanGrad)"
            strokeWidth="5"
            strokeLinecap="round"
            filter="url(#neonGlow)"
          />

          {/* Intersecting Orbit Rings */}
          <path
            d="M 28 85 A 80 80 0 0 1 150 28"
            stroke="#38bdf8"
            strokeWidth="2.5"
            strokeDasharray="4 6"
            strokeOpacity="0.7"
          />
          <path
            d="M 172 115 A 80 80 0 0 1 50 172"
            stroke="#f97316"
            strokeWidth="2.5"
            strokeDasharray="4 6"
            strokeOpacity="0.7"
          />

          {/* Inner LC Monogram - Bold 3D Angular Polygons */}
          {/* Letter L - Electric Cyan */}
          <path
            d="M 64 36 L 90 36 L 90 108 L 118 108 L 108 128 L 48 128 L 48 56 Z"
            fill="url(#lufiCyanGrad)"
            stroke="#0ea5e9"
            strokeWidth="2"
            strokeLinejoin="bevel"
            filter="url(#neonGlow)"
          />
          {/* Letter L bevel highlight */}
          <path
            d="M 64 36 L 76 46 L 76 100 L 98 100 L 108 128 L 90 108 L 90 36 Z"
            fill="#7dd3fc"
            fillOpacity="0.35"
          />

          {/* Letter C - Fiery Orange Interlocking */}
          <path
            d="M 108 52 L 150 52 L 138 72 L 124 72 L 110 88 L 126 106 L 152 106 L 140 126 L 94 126 L 86 114 L 86 96 L 100 78 Z"
            fill="url(#lufiOrangeGrad)"
            stroke="#f97316"
            strokeWidth="2"
            strokeLinejoin="bevel"
            filter="url(#neonGlow)"
          />
          {/* Letter C bevel highlight */}
          <path
            d="M 108 52 L 118 62 L 138 62 L 124 72 L 108 52 Z"
            fill="#fef08a"
            fillOpacity="0.45"
          />
        </svg>
      </div>

      {/* Brand Text Typography */}
      {showText && (
        <div className="flex flex-col tracking-tight">
          <div className={`font-black uppercase flex items-center font-display ${currentSize.text} leading-none tracking-wider`}>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300">
              LU
            </span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-500 to-amber-500">
              FI
            </span>
          </div>
          <div className="flex items-center gap-1.5 mt-1">
            <span className="h-[1.5px] w-3 bg-cyan-500/80 rounded-full" />
            <span className={`font-bold tracking-[0.28em] text-slate-300 uppercase font-display ${currentSize.sub}`}>
              COMMUNITY
            </span>
            <span className="h-[1.5px] w-3 bg-orange-500/80 rounded-full" />
          </div>
        </div>
      )}
    </div>
  );
};
