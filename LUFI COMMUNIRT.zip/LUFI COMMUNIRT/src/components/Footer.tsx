import React from 'react';
import { LufiLogo } from './LufiLogo';
import { DISCORD_INVITE_URL } from '../data/discordChannels';
import { ExternalLink, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#05070a] border-t border-slate-800/80 py-12 text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 pb-8 border-b border-slate-800/60">
          {/* Brand */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <LufiLogo size="sm" />
            <p className="mt-2 text-xs text-slate-400 max-w-sm">
              O maior ecossistema de acervo digital, fornecedores e softwares com acesso vitalício do Brasil.
            </p>
          </div>

          {/* Quick links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-xs font-medium">
            <a href="#inicio" className="hover:text-white transition-colors">
              Início
            </a>
            <a href="#salas" className="hover:text-white transition-colors">
              Salas do Discord
            </a>
            <a href="#precos" className="hover:text-white transition-colors">
              Preços Promocionais
            </a>
            <a
              href={DISCORD_INVITE_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-cyan-400 transition-colors inline-flex items-center gap-1 text-cyan-400 font-bold"
            >
              <span>Discord Oficial</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Bottom row */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500 text-center sm:text-left">
          <div>
            © {new Date().getFullYear()} LUFI COMMUNITY. Nossas vendas são feitas pelo sistema de bot da <strong className="text-cyan-400">CENTRAL CART</strong>, uma plataforma de pagamentos.
          </div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span>Sistema Seguro CENTRAL CART · Pagamentos Automáticos e Entrega Instantânea</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
