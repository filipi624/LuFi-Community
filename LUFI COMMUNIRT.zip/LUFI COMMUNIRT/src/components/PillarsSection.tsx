import React from 'react';
import { DISCORD_INVITE_URL } from '../data/discordChannels';
import {
  Boxes,
  Cpu,
  TrendingUp,
  PackageCheck,
  CheckCircle2,
  ExternalLink,
  Zap,
  Sparkles,
  Shield,
  Layers
} from 'lucide-react';

interface PillarsSectionProps {
  onOpenCheckoutModal?: () => void;
}

export const PillarsSection: React.FC<PillarsSectionProps> = ({ onOpenCheckoutModal }) => {
  const handleBuy = () => {
    if (onOpenCheckoutModal) {
      onOpenCheckoutModal();
    } else {
      window.open(DISCORD_INVITE_URL, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <section id="fornecedores" className="py-20 bg-[#07090e] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 mb-3">
            <span className="text-cyan-400 uppercase tracking-wider">Acervo Sem Limites</span>
            <span aria-hidden="true">·</span>
            <span>Zero Mensalidades</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white font-display text-balance">
            Tudo o Que Você Precisa Para Lucrar e Escalar em Um Só Lugar
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-400">
            Chega de gastar rios de dinheiro em mensalidades de ferramentas caras ou comprar listas
            ultrapassadas. Na LUFI COMMUNITY você tem o arsenal completo liberado.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Bento Card 1: Fornecedores de Fábrica (7 Cols) */}
          <div className="md:col-span-7 bg-[#0d121c] border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-xl relative overflow-hidden group hover:border-cyan-500/40 transition-all duration-300">
            <div className="space-y-4">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Boxes className="w-5 h-5" />
              </div>

              <div>
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  01. Fornecedores Direto da Fábrica
                </span>
                <h3 className="text-2xl font-bold text-white mt-1 font-display">
                  Atacado Físico & Marketplaces Digitais
                </h3>
              </div>

              <p className="text-sm text-slate-300 leading-relaxed">
                Acesse contatos diretos de fornecedores validados que os grandes lojistas escondem a
                sete chaves. Margens de lucro reais para revender e lucrar imediatamente.
              </p>

              {/* Showcase Image for Wholesale */}
              <div className="my-4 rounded-xl overflow-hidden border border-slate-800 relative h-48 bg-slate-900">
                <img
                  src="/src/assets/images/lufi_wholesale_showcase_1792000216950.jpg"
                  alt="Showcase de produtos fornecedores atacado"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-3">
                  <div className="text-xs text-white font-medium">
                    Tênis importados, iPhones, perfumes, joias, relógios e periféricos
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Roupas streetwear e grifes</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Eletrônicos e iPhones atacado</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Chaves Windows e Office a centavos</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Roblox Robux e Marketplaces globais</span>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800/80 mt-6 flex items-center justify-between">
              <span className="text-xs text-slate-400 font-mono">15 canais dedicados</span>
              <button
                onClick={handleBuy}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-cyan-400 hover:text-cyan-300"
              >
                <span>Acessar Fornecedores</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Bento Card 2: Softwares & Automações (5 Cols) */}
          <div
            id="softwares"
            className="md:col-span-5 bg-[#0d121c] border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-xl relative overflow-hidden group hover:border-orange-500/40 transition-all duration-300"
          >
            <div className="space-y-4">
              <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
                <Cpu className="w-5 h-5" />
              </div>

              <div>
                <span className="text-xs font-bold text-orange-400 uppercase tracking-wider">
                  02. Softwares Vitalícios
                </span>
                <h3 className="text-2xl font-bold text-white mt-1 font-display">
                  Economize Milhares em Mensalidades
                </h3>
              </div>

              <p className="text-sm text-slate-300 leading-relaxed">
                Tenha em mãos as ferramentas que os profissionais usam para automatizar vendas e
                atendimentos, sem pagar R$ 197 a R$ 497 todo mês.
              </p>

              <div className="space-y-2 pt-2">
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">WA Sender Vitalício</div>
                    <div className="text-[11px] text-slate-400">Disparo em massa de WhatsApp</div>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-400">Economia R$ 497</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">Zap Voice Vitalício</div>
                    <div className="text-[11px] text-slate-400">Envio de áudios gravados na hora</div>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-400">Economia R$ 397</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">Fluxos n8n & Typerbot</div>
                    <div className="text-[11px] text-slate-400">Automações prontas para CRM</div>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-400">Incluso</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">Clonador de Páginas & VSL</div>
                    <div className="text-[11px] text-slate-400">Modele concorrentes com 1 clique</div>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-400">Incluso</span>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800/80 mt-6 flex items-center justify-between">
              <span className="text-xs text-slate-400 font-mono">14 ferramentas prontas</span>
              <button
                onClick={handleBuy}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-orange-400 hover:text-orange-300"
              >
                <span>Baixar Softwares</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Bento Card 3: Tráfego, Marketing & PLRs (6 Cols) */}
          <div className="md:col-span-6 bg-[#0d121c] border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-xl relative overflow-hidden group hover:border-sky-500/40 transition-all duration-300">
            <div className="space-y-4">
              <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
                <TrendingUp className="w-5 h-5" />
              </div>

              <div>
                <span className="text-xs font-bold text-sky-400 uppercase tracking-wider">
                  03. Máquina de Tráfego & Vendas
                </span>
                <h3 className="text-2xl font-bold text-white mt-1 font-display">
                  Páginas, Copys e Funis Prontos
                </h3>
              </div>

              <p className="text-sm text-slate-300 leading-relaxed">
                Não comece do zero. Use estruturas validadas com alta conversão testada no mercado:
                templates de páginas de vendas, scripts persuasivos, contingência para anúncios e
                gerador de prova social.
              </p>

              <div className="space-y-2 pt-2 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                  <span>Páginas de vendas prontas para Elementor e HTML</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                  <span>PLRs com direitos de revenda (100% de lucro seu)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                  <span>Aquecimento de WhatsApp para evitar banimentos</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                  <span>Cursos completos dos maiores nomes do mercado</span>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800/80 mt-6 flex items-center justify-between">
              <span className="text-xs text-slate-400 font-mono">Tráfego pago & orgânico</span>
              <button
                onClick={handleBuy}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-sky-400 hover:text-sky-300"
              >
                <span>Desbloquear Marketing</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Bento Card 4: Mega Packs & Variados (6 Cols) */}
          <div className="md:col-span-6 bg-[#0d121c] border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-xl relative overflow-hidden group hover:border-amber-500/40 transition-all duration-300">
            <div className="space-y-4">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <PackageCheck className="w-5 h-5" />
              </div>

              <div>
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                  04. Acervo Multimídia & Mega Drives
                </span>
                <h3 className="text-2xl font-bold text-white mt-1 font-display">
                  Vídeos Virais, Design e Conhecimento
                </h3>
              </div>

              <p className="text-sm text-slate-300 leading-relaxed">
                Tudo o que você precisa para criar canais dark de sucesso, artes profissionais para
                empresas e se capacitar com materiais de alto nível.
              </p>

              <div className="space-y-2 pt-2 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Cortes virais prontos e legendados para TikTok e Reels</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Milhares de artes editáveis no Canva (Canva Tudo)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Modelos de contratos jurídicos blindados</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Drives compartilhados com Terabytes de arquivos raros</span>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800/80 mt-6 flex items-center justify-between">
              <span className="text-xs text-slate-400 font-mono">Terabytes em acervo</span>
              <button
                onClick={handleBuy}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-400 hover:text-amber-300"
              >
                <span>Explorar Drives</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
