import React, { useState } from 'react';
import { DISCORD_INVITE_URL } from '../data/discordChannels';
import { ExternalLink, Check, ArrowDown, Tag, Copy, Sparkles, XCircle, CheckCircle2, Star, Cpu, ShieldCheck } from 'lucide-react';

interface HeroSectionProps {
  onOpenCheckoutModal?: (plan?: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenCheckoutModal }) => {
  const [selectedPlan, setSelectedPlan] = useState<'superpack' | 'fornecedores'>('superpack');
  const [copiedCoupon, setCopiedCoupon] = useState(false);

  const handleCopyCoupon = () => {
    navigator.clipboard.writeText('27off');
    setCopiedCoupon(true);
    setTimeout(() => setCopiedCoupon(false), 2500);
  };

  const handleBuy = (plan: string) => {
    if (onOpenCheckoutModal) {
      onOpenCheckoutModal(plan);
    } else {
      window.open(DISCORD_INVITE_URL, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <section id="inicio" className="relative pt-24 pb-14 md:pt-32 md:pb-20 overflow-hidden bg-[#07090e]">
      {/* Subtle ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-gradient-to-b from-cyan-600/15 via-orange-500/10 to-transparent blur-[120px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Main Title */}
        <div className="text-center max-w-3xl mx-auto mb-8">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 mb-3 bg-slate-900/90 px-3.5 py-1.5 rounded-full border border-slate-800">
            <span className="text-cyan-400 font-bold">LUFI COMMUNITY</span>
            <span aria-hidden="true">·</span>
            <span className="text-orange-400 font-bold">ACESSO VITALÍCIO</span>
            <span aria-hidden="true">·</span>
            <span>LIBERAMOS TUDO</span>
          </div>

          <h1 className="text-3xl sm:text-5xl md:text-6xl font-black tracking-tight text-white font-display leading-[1.1] text-balance">
            O Maior Acervo Digital da Internet.{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-orange-400">
              Acesso Vitalício.
            </span>
          </h1>

          <p className="mt-3 text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl mx-auto">
            Liberamos literalmente de tudo no Discord: fornecedores de fábrica, softwares vitalícios,
            automações e cursos completos.
          </p>
        </div>

        {/* Cupom 27off Highlight Banner - Válido para os 2! */}
        <div className="max-w-2xl mx-auto mb-8 bg-gradient-to-r from-orange-950/60 via-amber-950/40 to-cyan-950/50 border-2 border-orange-500/60 rounded-2xl p-4 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/20 border border-orange-500/40 flex items-center justify-center text-orange-400 shrink-0">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-orange-300 font-bold uppercase tracking-wider flex items-center gap-2">
                <span>Cupom Ativo:</span>
                <span className="px-2 py-0.5 text-xs bg-black/80 text-amber-300 rounded font-mono font-black border border-orange-500/40">
                  27off
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded font-bold">
                  -R$ 27,00 OFF EM QUALQUER PACK
                </span>
              </div>
              <div className="text-xs sm:text-sm text-slate-200 mt-0.5">
                R$ 27 de desconto tanto no <strong>Superpack</strong> quanto nos <strong>Fornecedores</strong>!
              </div>
            </div>
          </div>

          <button
            onClick={handleCopyCoupon}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-orange-950/60 active:scale-95 transition-all shrink-0 cursor-pointer"
          >
            {copiedCoupon ? (
              <>
                <Check className="w-4 h-4 text-white" />
                <span>Cupom Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copiar Cupom 27off</span>
              </>
            )}
          </button>
        </div>

        {/* Interactive Segmented Selector - Superpack vs Fornecedores */}
        <div id="precos" className="mb-6">
          <div className="text-center mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Selecione o que você deseja para ver o valor:
            </span>
          </div>

          <div className="grid grid-cols-2 p-1.5 bg-[#101422] rounded-2xl border border-slate-800 max-w-lg mx-auto shadow-xl">
            <button
              onClick={() => setSelectedPlan('superpack')}
              className={`flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
                selectedPlan === 'superpack'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-950/60 scale-[1.02]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Cpu className="w-4 h-4 text-cyan-300 shrink-0" />
              <span>SUPERPACK</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-black/40 text-emerald-300 font-bold">
                R$ 32
              </span>
            </button>

            <button
              onClick={() => setSelectedPlan('fornecedores')}
              className={`flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
                selectedPlan === 'fornecedores'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg shadow-orange-950/60 scale-[1.02]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Star className="w-4 h-4 text-amber-300 shrink-0" />
              <span>FORNECEDORES</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-black/40 text-emerald-300 font-bold">
                R$ 12
              </span>
            </button>
          </div>
        </div>

        {/* Single Dynamic Card - Selected Plan */}
        <div className="max-w-2xl mx-auto mb-10">
          {selectedPlan === 'superpack' ? (
            /* SUPERPACK CARD */
            <div className="bg-[#0c101c] border-2 border-cyan-500/60 rounded-3xl p-6 sm:p-8 shadow-2xl relative transition-all animate-fade-in">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Cpu className="w-4 h-4" />
                  <span>Acesso Superpack Selecionado</span>
                </span>
                <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Cupom 27off Ativo
                </span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-black text-white font-display">
                SUPERPACK VITALÍCIO
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                Softwares com licença vitalícia, automações, apps, tráfego e cursos.
              </p>

              {/* Price Box with Coupon Applied */}
              <div className="my-6 p-5 rounded-2xl bg-slate-900/90 border border-cyan-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Preço padrão:</span>
                  <span className="line-through text-slate-400 font-mono text-sm">R$ 59,00</span>
                </div>
                <div className="flex items-center justify-between text-xs text-orange-400">
                  <span>Desconto com cupom 27off:</span>
                  <span className="font-mono font-bold">-R$ 27,00</span>
                </div>
                <div className="pt-2.5 border-t border-slate-800 flex items-baseline justify-between">
                  <div className="text-xs font-bold text-emerald-400">
                    Você paga apenas:
                  </div>
                  <div className="text-4xl font-black text-white font-mono">
                    R$ 32<span className="text-lg text-slate-400">,00</span>
                  </div>
                </div>
                <div className="text-[11px] text-emerald-400 font-medium">
                  Pagamento único · Acesso vitalício a mais de 37 salas no Discord
                </div>
              </div>

              {/* Highlights */}
              <div className="space-y-2.5 text-xs sm:text-sm text-slate-200 mb-6">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span><strong>WA Sender Vitalício:</strong> Disparo de WhatsApp ilimitado sem mensalidade</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span><strong>Zap Voice Vitalício:</strong> Envio de áudios como se fossem gravados na hora</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span><strong>Typerbot & n8n:</strong> Automações completas de CRM e atendimento</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span><strong>Clonador de Páginas & VSLs:</strong> Copie páginas vencedoras em 1 clique</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span><strong>IPTV Vitalício, Extensões & Apps:</strong> Sem faturas mensais</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span><strong>Tráfego, Páginas Prontas, PLRs e Cortes Virais</strong></span>
                </div>
              </div>

              <button
                onClick={() => handleBuy('Superpack')}
                className="w-full py-4 px-6 rounded-2xl font-extrabold uppercase tracking-wider text-sm sm:text-base text-white bg-gradient-to-r from-cyan-500 via-sky-600 to-blue-600 hover:from-cyan-400 hover:to-blue-500 shadow-xl shadow-cyan-950/60 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Comprar Superpack por R$ 32 no Discord</span>
                <ExternalLink className="w-4 h-4" />
              </button>

              {/* Central Cart Security Notice */}
              <div className="mt-3.5 pt-3 border-t border-slate-800/80 flex items-center justify-center gap-2 text-xs text-slate-400 text-center">
                <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>
                  Vendas e entregas 100% automáticas pelo bot da <strong className="text-cyan-300">CENTRAL CART</strong> (Pix e Cartão)
                </span>
              </div>
            </div>
          ) : (
            /* FORNECEDORES CARD */
            <div className="bg-[#0c101c] border-2 border-amber-500/60 rounded-3xl p-6 sm:p-8 shadow-2xl relative transition-all animate-fade-in">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Star className="w-4 h-4" />
                  <span>Acesso Fornecedores Selecionado</span>
                </span>
                <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Cupom 27off Ativo
                </span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-black text-white font-display">
                FORNECEDORES VITALÍCIO
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                Atacado físico direto da fábrica e fornecedores de contas e ativos digitais.
              </p>

              {/* Price Box with Coupon Applied */}
              <div className="my-6 p-5 rounded-2xl bg-slate-900/90 border border-amber-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Preço padrão:</span>
                  <span className="line-through text-slate-400 font-mono text-sm">R$ 39,00</span>
                </div>
                <div className="flex items-center justify-between text-xs text-orange-400">
                  <span>Desconto com cupom 27off:</span>
                  <span className="font-mono font-bold">-R$ 27,00</span>
                </div>
                <div className="pt-2.5 border-t border-slate-800 flex items-baseline justify-between">
                  <div className="text-xs font-bold text-emerald-400">
                    Você paga apenas:
                  </div>
                  <div className="text-4xl font-black text-white font-mono">
                    R$ 12<span className="text-lg text-slate-400">,00</span>
                  </div>
                </div>
                <div className="text-[11px] text-emerald-400 font-medium">
                  Pagamento único · Acesso vitalício a 15 salas de fornecedores validados
                </div>
              </div>

              {/* Highlights */}
              <div className="space-y-2.5 text-xs sm:text-sm text-slate-200 mb-6">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-amber-400 shrink-0" />
                  <span><strong>Roupas Streetwear & Grifes:</strong> Fábricas diretas com preço de atacado</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-amber-400 shrink-0" />
                  <span><strong>Eletrônicos & iPhones:</strong> Lacrados e de vitrine com alta margem</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-amber-400 shrink-0" />
                  <span><strong>Tênis Importados:</strong> Nike Dunk, Jordan, Adidas Samba linha premium</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-amber-400 shrink-0" />
                  <span><strong>Perfumes Importados, Joias e Relógios</strong> no atacado</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-amber-400 shrink-0" />
                  <span><strong>Marketplaces Globais:</strong> Compras na Ásia e leste europeu</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-amber-400 shrink-0" />
                  <span><strong>Chaves Windows/Office a centavos e Roblox Robux</strong></span>
                </div>
              </div>

              <button
                onClick={() => handleBuy('Fornecedores')}
                className="w-full py-4 px-6 rounded-2xl font-extrabold uppercase tracking-wider text-sm sm:text-base text-white bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 shadow-xl shadow-orange-950/60 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Comprar Fornecedores por R$ 12 no Discord</span>
                <ExternalLink className="w-4 h-4" />
              </button>

              {/* Central Cart Security Notice */}
              <div className="mt-3.5 pt-3 border-t border-slate-800/80 flex items-center justify-center gap-2 text-xs text-slate-400 text-center">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  Vendas e entregas 100% automáticas pelo bot da <strong className="text-amber-300">CENTRAL CART</strong> (Pix e Cartão)
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Banner Oficial da Plataforma de Pagamentos - CENTRAL CART */}
        <div className="max-w-2xl mx-auto mb-10 bg-gradient-to-r from-[#0c1424] via-[#0f172a] to-[#0c1424] border border-cyan-500/40 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0 shadow-lg shadow-cyan-950/50">
              <ShieldCheck className="w-6 h-6" />
            </div>

            <div className="flex-1 text-center sm:text-left">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-bold uppercase tracking-wider mb-1.5 border border-cyan-500/30">
                <span>Plataforma Oficial de Pagamento</span>
              </div>
              <h3 className="text-base sm:text-lg font-black text-white font-display">
                Vendas 100% Automáticas via Bot da <span className="text-cyan-400">CENTRAL CART</span>
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 mt-1.5 leading-relaxed">
                Nossas vendas são feitas pelo sistema de bot da <strong>CENTRAL CART</strong>, uma plataforma de pagamentos segura e rápida no Discord. Você realiza o Pix ou Cartão e recebe seu acesso VIP no mesmo segundo!
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-3.5 pt-3 border-t border-slate-800 text-[11px] text-slate-300">
                <div className="flex items-center gap-1.5 justify-center sm:justify-start">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                  <span><strong>Entrega Automática:</strong> Pix aprovado na hora</span>
                </div>
                <div className="flex items-center gap-1.5 justify-center sm:justify-start">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 shrink-0" />
                  <span><strong>Cargo VIP Instantâneo:</strong> Sem filas no Discord</span>
                </div>
                <div className="flex items-center gap-1.5 justify-center sm:justify-start">
                  <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                  <span><strong>Cupom 27off:</strong> Desconto de R$ 27 no bot</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Clear Price Comparison: "Quanto você pagaria vs Quanto vai pagar na LUFI" */}
        <div className="max-w-3xl mx-auto mb-10 bg-[#0a0d16] border border-slate-800 rounded-2xl p-6 sm:p-7 shadow-2xl">
          <div className="text-center mb-5">
            <span className="text-xs font-bold text-orange-400 uppercase tracking-widest">
              Comparativo Real de Mercado
            </span>
            <h3 className="text-lg sm:text-xl font-black text-white font-display mt-1">
              Quanto você pagaria por fora vs Quanto paga na LUFI COMMUNITY
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-stretch text-xs">
            {/* Comprando por fora */}
            <div className="bg-[#0f1320] border border-rose-950/50 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="font-bold text-rose-400 uppercase">Por fora na internet</span>
                <XCircle className="w-4 h-4 text-rose-500" />
              </div>
              <div className="space-y-1.5 text-slate-400">
                <div className="flex justify-between">
                  <span>Listas de Fornecedores:</span>
                  <span className="text-slate-300 font-mono">R$ 400,00</span>
                </div>
                <div className="flex justify-between">
                  <span>WA Sender (disparador):</span>
                  <span className="text-slate-300 font-mono">R$ 497,00</span>
                </div>
                <div className="flex justify-between">
                  <span>Zap Voice (áudios na hora):</span>
                  <span className="text-slate-300 font-mono">R$ 397,00/ano</span>
                </div>
                <div className="flex justify-between">
                  <span>Cursos, PLRs e Páginas:</span>
                  <span className="text-slate-300 font-mono">R$ 1.200,00+</span>
                </div>
                <div className="flex justify-between">
                  <span>Automações n8n & Apps:</span>
                  <span className="text-slate-300 font-mono">R$ 500,00+</span>
                </div>
              </div>
              <div className="pt-2 border-t border-slate-800 flex justify-between items-baseline font-bold">
                <span className="text-slate-400">Total individual:</span>
                <span className="text-rose-400 font-mono line-through text-base">R$ 2.994,00+</span>
              </div>
            </div>

            {/* Na LUFI COMMUNITY com cupom */}
            <div className="bg-gradient-to-b from-[#111728] to-[#0d1222] border-2 border-cyan-500/50 rounded-xl p-4 space-y-2 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className="font-bold text-cyan-400 uppercase">Na LUFI COMMUNITY (Cupom 27off)</span>
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="space-y-2 mt-2">
                  <div className="p-2 rounded bg-amber-500/10 border border-amber-500/20 flex justify-between items-center">
                    <div>
                      <strong className="text-amber-300">Pack Fornecedores:</strong>
                      <div className="text-[10px] text-slate-400">De R$ 39 com cupom 27off</div>
                    </div>
                    <span className="text-base font-black text-white font-mono">R$ 12,00</span>
                  </div>

                  <div className="p-2 rounded bg-cyan-500/10 border border-cyan-500/20 flex justify-between items-center">
                    <div>
                      <strong className="text-cyan-300">Superpack:</strong>
                      <div className="text-[10px] text-slate-400">De R$ 59 com cupom 27off</div>
                    </div>
                    <span className="text-base font-black text-emerald-400 font-mono">R$ 32,00</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                <span className="text-emerald-400 font-bold">Mais de 98% de economia</span>
                <span className="text-slate-400 font-mono">Acesso vitalício</span>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll link to Discord Channels */}
        <div className="text-center">
          <a
            href="#salas"
            className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-400 hover:text-cyan-400 transition-colors"
          >
            <span>Ver exatamente todas as salas do Discord abaixo</span>
            <ArrowDown className="w-4 h-4 text-cyan-400 animate-bounce" />
          </a>
        </div>
      </div>
    </section>
  );
};
